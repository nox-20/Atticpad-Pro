package net.atticpad

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class PadLayoutTest {

    @Test
    fun defaultLandscapeHasRequiredControls() {
        val layout = PadLayout.defaultLandscape()
        val ids = layout.controls.map { it.id }

        assertTrue(ids.contains("stick_l"))
        assertTrue(ids.contains("stick_r"))
        assertTrue(ids.contains("dpad"))
        assertTrue(ids.contains("a"))
        assertTrue(ids.contains("b"))
        assertTrue(ids.contains("x"))
        assertTrue(ids.contains("y"))
        assertTrue(ids.contains("l"))
        assertTrue(ids.contains("zl"))
        assertTrue(ids.contains("r"))
        assertTrue(ids.contains("zr"))
        assertTrue(ids.contains("start"))
        assertTrue(ids.contains("select"))
        assertTrue(ids.contains("home"))
    }

    @Test
    fun defaultPortraitHasRequiredControls() {
        val layout = PadLayout.defaultPortrait()
        val ids = layout.controls.map { it.id }

        assertTrue(ids.contains("stick_l"))
        assertTrue(ids.contains("stick_r"))
        assertTrue(ids.contains("dpad"))
        assertTrue(ids.contains("a"))
        assertTrue(ids.contains("b"))
        assertTrue(ids.contains("x"))
        assertTrue(ids.contains("y"))
        assertTrue(ids.contains("home"))
    }

    @Test
    fun jsonRoundTripPreservesProperties() {
        val original = PadLayout.defaultLandscape()
        val stickL = original.getControl("stick_l")!!
        stickL.cx = 0.22f
        stickL.cy = 0.55f
        stickL.r = 0.18f
        stickL.opacity = 0.75f

        val json = original.toJson()
        val restored = PadLayout.fromJson(json, PadLayout.Orientation.LANDSCAPE)
        val restoredStick = restored.getControl("stick_l")

        assertNotNull(restoredStick)
        assertEquals(0.22f, restoredStick!!.cx, 0.001f)
        assertEquals(0.55f, restoredStick.cy, 0.001f)
        assertEquals(0.18f, restoredStick.r, 0.001f)
        assertEquals(0.75f, restoredStick.opacity, 0.001f)
    }

    @Test
    fun adjustActionButtonsSpreadModifiesRadialDistance() {
        val layout = PadLayout.defaultLandscape()
        val aBefore = layout.getControl("a")!!.cx
        val yBefore = layout.getControl("y")!!.cx
        val distBefore = aBefore - yBefore

        layout.adjustActionButtonsSpread(1.20f)

        val aAfter = layout.getControl("a")!!.cx
        val yAfter = layout.getControl("y")!!.cx
        val distAfter = aAfter - yAfter

        assertTrue("Radial distance should increase after spread expansion", distAfter > distBefore)
    }

    @Test
    fun nudgeControlAdjustsPositionAccurately() {
        val layout = PadLayout.defaultLandscape()
        val c = layout.getControl("home")!!
        val startX = c.cx
        val startY = c.cy

        layout.nudgeControl("home", 0.02f, -0.01f)

        assertEquals(startX + 0.02f, c.cx, 0.001f)
        assertEquals(startY - 0.01f, c.cy, 0.001f)
    }
}
