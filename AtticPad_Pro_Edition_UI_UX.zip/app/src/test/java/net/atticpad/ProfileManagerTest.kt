package net.atticpad

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class ProfileManagerTest {

    private lateinit var context: Context
    private lateinit var profileManager: ProfileManager

    @Before
    fun setUp() {
        context = ApplicationProvider.getApplicationContext()
        context.getSharedPreferences("atticpad_profiles_v1", Context.MODE_PRIVATE).edit().clear().commit()
        profileManager = ProfileManager.getInstance(context)
    }

    @Test
    fun hasDefaultPresetsAvailable() {
        val profiles = profileManager.listProfiles()
        assertTrue(profiles.isNotEmpty())
        val names = profiles.map { it.name }
        assertTrue(names.any { it.contains("Predeterminado") })
        assertTrue(names.any { it.contains("Lucha") })
        assertTrue(names.any { it.contains("Carreras") })
        assertTrue(names.any { it.contains("Acción") })
    }

    @Test
    fun createAndSwitchProfile() {
        val created = profileManager.createProfile("Custom Game")
        assertEquals("Custom Game", created.name)

        val active = profileManager.getActiveProfile()
        assertEquals(created.id, active.id)
    }

    @Test
    fun duplicateProfilePreservesLayouts() {
        val active = profileManager.getActiveProfile()
        val duplicated = profileManager.duplicateProfile(active.id)

        assertEquals("${active.name} (Copia)", duplicated.name)
        assertEquals(active.style, duplicated.style)
        assertEquals(active.landscapeLayout.controls.size, duplicated.landscapeLayout.controls.size)
    }

    @Test
    fun renameProfileWorks() {
        val active = profileManager.getActiveProfile()
        val success = profileManager.renameProfile(active.id, "Renamed Profile")

        assertTrue(success)
        assertEquals("Renamed Profile", profileManager.getActiveProfile().name)
    }

    @Test
    fun cannotDeleteSoleProfile() {
        // Delete all except one
        val profiles = profileManager.listProfiles()
        for (i in 1 until profiles.size) {
            profileManager.deleteProfile(profiles[i].id)
        }
        assertEquals(1, profileManager.listProfiles().size)
        val deleted = profileManager.deleteProfile(profileManager.listProfiles().first().id)
        assertFalse("Cannot delete the only remaining profile", deleted)
    }
}
