package net.atticpad

import org.junit.Assert.assertEquals
import org.junit.Test

class VisualThemeTest {

    @Test
    fun xboxVisualMappingCorrectPhysicalPositions() {
        // Physical bottom (Nintendo B) -> Xbox "A" (Green)
        val bVisual = VisualTheme.getVisual("b", ButtonStyle.XBOX, active = false)
        assertEquals("A", bVisual.label)
        assertEquals(VisualTheme.XBOX_GREEN, bVisual.strokeColor)

        // Physical right (Nintendo A) -> Xbox "B" (Red)
        val aVisual = VisualTheme.getVisual("a", ButtonStyle.XBOX, active = false)
        assertEquals("B", aVisual.label)
        assertEquals(VisualTheme.XBOX_RED, aVisual.strokeColor)

        // Physical left (Nintendo Y) -> Xbox "X" (Blue)
        val yVisual = VisualTheme.getVisual("y", ButtonStyle.XBOX, active = false)
        assertEquals("X", yVisual.label)
        assertEquals(VisualTheme.XBOX_BLUE, yVisual.strokeColor)

        // Physical top (Nintendo X) -> Xbox "Y" (Yellow)
        val xVisual = VisualTheme.getVisual("x", ButtonStyle.XBOX, active = false)
        assertEquals("Y", xVisual.label)
        assertEquals(VisualTheme.XBOX_YELLOW, xVisual.strokeColor)
    }

    @Test
    fun playstationVisualMappingCorrectSymbols() {
        // Bottom -> Cross (Cyan/Blue)
        val bVisual = VisualTheme.getVisual("b", ButtonStyle.PLAYSTATION, active = false)
        assertEquals(SymbolType.CROSS, bVisual.symbol)
        assertEquals(VisualTheme.PS_BLUE, bVisual.strokeColor)

        // Right -> Circle (Red)
        val aVisual = VisualTheme.getVisual("a", ButtonStyle.PLAYSTATION, active = false)
        assertEquals(SymbolType.CIRCLE, aVisual.symbol)
        assertEquals(VisualTheme.PS_RED, aVisual.strokeColor)

        // Left -> Square (Pink)
        val yVisual = VisualTheme.getVisual("y", ButtonStyle.PLAYSTATION, active = false)
        assertEquals(SymbolType.SQUARE, yVisual.symbol)
        assertEquals(VisualTheme.PS_PINK, yVisual.strokeColor)

        // Top -> Triangle (Green)
        val xVisual = VisualTheme.getVisual("x", ButtonStyle.PLAYSTATION, active = false)
        assertEquals(SymbolType.TRIANGLE, xVisual.symbol)
        assertEquals(VisualTheme.PS_GREEN, xVisual.strokeColor)
    }

    @Test
    fun nintendoVisualMappingCorrectLabels() {
        assertEquals("A", VisualTheme.getVisual("a", ButtonStyle.NINTENDO, false).label)
        assertEquals("B", VisualTheme.getVisual("b", ButtonStyle.NINTENDO, false).label)
        assertEquals("X", VisualTheme.getVisual("x", ButtonStyle.NINTENDO, false).label)
        assertEquals("Y", VisualTheme.getVisual("y", ButtonStyle.NINTENDO, false).label)
    }
}
