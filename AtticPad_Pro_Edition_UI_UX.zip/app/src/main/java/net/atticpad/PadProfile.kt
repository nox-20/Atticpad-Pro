package net.atticpad

import org.json.JSONObject


/**
 * Data model for a complete gamepad configuration profile.
 *
 * Each profile encapsulates:
 * - Unique identifier and user-defined name
 * - Visual style (Xbox, PlayStation, Clásico Nintendo)
 * - Independent layouts for LANDSCAPE and PORTRAIT orientations
 *   (each saving control positions, sizes, opacities, and action button spread)
 * - Macro sequences assigned to specific controls
 */
data class PadProfile(
    val id: String,
    var name: String,
    var style: ButtonStyle = ButtonStyle.NINTENDO,
    val landscapeLayout: PadLayout,
    val portraitLayout: PadLayout,
    val macros: MutableMap<String, Macro> = mutableMapOf()
) {
    fun copy(newId: String = id, newName: String = name): PadProfile {
        val copiedMacros = mutableMapOf<String, Macro>()
        macros.forEach { (k, v) ->
            copiedMacros[k] = v.deepCopy()
        }
        return PadProfile(
            id = newId,
            name = newName,
            style = style,
            landscapeLayout = landscapeLayout.copy(),
            portraitLayout = portraitLayout.copy(),
            macros = copiedMacros
        )
    }

    fun layoutFor(orientation: PadLayout.Orientation): PadLayout = when (orientation) {
        PadLayout.Orientation.LANDSCAPE -> landscapeLayout
        PadLayout.Orientation.PORTRAIT -> portraitLayout
    }

    fun toJson(): JSONObject {
        val macrosJson = JSONObject()
        macros.forEach { (btnId, macro) ->
            macrosJson.put(btnId, macro.toJson())
        }
        return JSONObject()
            .put("id", id)
            .put("name", name)
            .put("style", style.id)
            .put("landscape", JSONObject(landscapeLayout.toJson()))
            .put("portrait", JSONObject(portraitLayout.toJson()))
            .put("macros", macrosJson)
    }

    companion object {
        fun fromJson(json: JSONObject): PadProfile {
            val id = json.optString("id", "profile_${System.currentTimeMillis()}")
            val name = json.optString("name", "Perfil")
            val style = ButtonStyle.fromId(json.optString("style", "nintendo"))
            val landscapeStr = json.optJSONObject("landscape")?.toString() ?: ""
            val portraitStr = json.optJSONObject("portrait")?.toString() ?: ""

            val landLayout = if (landscapeStr.isNotEmpty()) {
                PadLayout.fromJson(landscapeStr, PadLayout.Orientation.LANDSCAPE)
            } else {
                PadLayout.defaultLandscape()
            }

            val portLayout = if (portraitStr.isNotEmpty()) {
                PadLayout.fromJson(portraitStr, PadLayout.Orientation.PORTRAIT)
            } else {
                PadLayout.defaultPortrait()
            }

            val macrosMap = mutableMapOf<String, Macro>()
            val macrosJson = json.optJSONObject("macros")
            if (macrosJson != null) {
                val keys = macrosJson.keys()
                while (keys.hasNext()) {
                    val key = keys.next()
                    val mObj = macrosJson.optJSONObject(key)
                    if (mObj != null) {
                        macrosMap[key] = Macro.fromJson(mObj)
                    }
                }
            }

            return PadProfile(id, name, style, landLayout, portLayout, macrosMap)
        }
    }
}
