package net.atticpad

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Collapsible animated top bar and discrete floating trigger for immersive gameplay.
 *
 * Requirements:
 * - Gamepad takes the entire screen with no fixed top bar or HUD during play.
 * - Small floating trigger (FAB/translucent pill) on top edge with reduced opacity (easy to tap).
 * - Clicking trigger expands the animated top bar with sections:
 *   Mando (Pad), Teclado (Keyboard), Ratón (Mouse), Multimedia (Media), Ajustes (Settings), and Close (✕).
 * - On closing, the bar collapses and reserved space drops to zero, expanding gamepad to full screen.
 * - Selecting any mode auto-collapses the bar so that mode takes full screen.
 */
class ImmersiveTopBar(
    context: Context,
    private val onSelectMode: (KbmMode) -> Unit,
    private val onOpenSettings: () -> Unit,
    private val onOpenMacros: (() -> Unit)? = null,
    private val onQuickProfile: (() -> Unit)? = null,
    private val onBarStateChanged: (isExpanded: Boolean) -> Unit
) : FrameLayout(context) {

    var isExpanded: Boolean = false
        private set

    val floatingTrigger: TextView
    private val topBarContainer: LinearLayout
    private val modeChips = LinkedHashMap<KbmMode, TextView>()
    private var profileChip: TextView? = null
    private var currentMode: KbmMode = KbmMode.PAD

    init {
        // --- 1. Small discrete floating trigger ---
        val triggerBg = GradientDrawable().apply {
            setColor(0x551C212B) // Semi-transparent dark slate
            cornerRadius = Theme.dp(context, 16).toFloat()
            setStroke(Theme.dp(context, 1), 0x4DFFFFFF)
        }

        floatingTrigger = TextView(context).apply {
            text = "☰"
            textSize = 15f
            setTextColor(0xCCFFFFFF.toInt())
            background = triggerBg
            gravity = Gravity.CENTER
            val hp = Theme.dp(context, 14); val vp = Theme.dp(context, 6)
            setPadding(hp, vp, hp, vp)
            alpha = 0.50f // Reduced opacity during play
            isClickable = true
            isFocusable = true
            setOnClickListener {
                toggleBar()
            }
        }

        // --- 2. Animated Top Bar container ---
        val barBg = GradientDrawable().apply {
            setColor(0xF21C212B.toInt()) // 95% opacity app background
            cornerRadius = Theme.dp(context, Theme.RADIUS_MD).toFloat()
            setStroke(Theme.dp(context, 1), 0x33FFFFFF)
        }

        topBarContainer = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            background = barBg
            gravity = Gravity.CENTER_VERTICAL
            val hp = Theme.dp(context, Theme.SPACE_SM); val vp = Theme.dp(context, Theme.SPACE_XS)
            setPadding(hp, vp, hp, vp)
            visibility = View.GONE
        }

        val scroll = HorizontalScrollView(context).apply {
            isHorizontalScrollBarEnabled = false
        }

        val chipsRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        fun createChip(mode: KbmMode, label: String): TextView {
            return TextView(context).apply {
                text = label
                textSize = 12f
                setTextColor(Theme.TEXT_PRIMARY)
                val padH = Theme.dp(context, Theme.SPACE_MD); val padV = Theme.dp(context, Theme.SPACE_SM)
                setPadding(padH, padV, padH, padV)
                gravity = Gravity.CENTER
                minimumHeight = Theme.dp(context, 38)
                background = Theme.chipBackground(context)
                isClickable = true
                isFocusable = true
                setOnClickListener {
                    currentMode = mode
                    updateChipStyles()
                    onSelectMode(mode)
                    collapseBar() // Auto-collapse so mode takes full screen!
                }
            }
        }

        modeChips[KbmMode.PAD] = createChip(KbmMode.PAD, "Mando")
        modeChips[KbmMode.KEYBOARD] = createChip(KbmMode.KEYBOARD, "Teclado")
        modeChips[KbmMode.MOUSE] = createChip(KbmMode.MOUSE, "Ratón")
        modeChips[KbmMode.MEDIA] = createChip(KbmMode.MEDIA, "Multimedia")

        for ((i, chip) in modeChips.values.withIndex()) {
            chipsRow.addView(
                chip,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    if (i > 0) marginStart = Theme.dp(context, Theme.SPACE_XS)
                }
            )
        }

        // Divider
        chipsRow.addView(
            View(context).apply { setBackgroundColor(Theme.OUTLINE) },
            LinearLayout.LayoutParams(Theme.dp(context, 1), Theme.dp(context, 22)).apply {
                marginStart = Theme.dp(context, Theme.SPACE_SM)
                marginEnd = Theme.dp(context, Theme.SPACE_XS)
            }
        )

        // Quick profile chip
        val pChip = TextView(context).apply {
            text = "🎮 Perfil"
            textSize = 12f
            setTextColor(Theme.TEXT_PRIMARY)
            val padH = Theme.dp(context, Theme.SPACE_MD); val padV = Theme.dp(context, Theme.SPACE_SM)
            setPadding(padH, padV, padH, padV)
            gravity = Gravity.CENTER
            minimumHeight = Theme.dp(context, 38)
            background = Theme.chipBackground(context)
            isClickable = true
            isFocusable = true
            setOnClickListener {
                onQuickProfile?.invoke()
            }
        }
        profileChip = pChip
        chipsRow.addView(pChip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            marginEnd = Theme.dp(context, Theme.SPACE_XS)
        })

        // Dedicated macro library, separate from layout editing.
        val macrosChip = TextView(context).apply {
            text = "⚡ Macros"
            textSize = 12f
            setTextColor(Theme.ACCENT)
            typeface = Theme.TYPE_MEDIUM
            val padH = Theme.dp(context, Theme.SPACE_MD); val padV = Theme.dp(context, Theme.SPACE_SM)
            setPadding(padH, padV, padH, padV)
            gravity = Gravity.CENTER
            minimumHeight = Theme.dp(context, 38)
            background = Theme.chipBackground(context)
            isClickable = true
            isFocusable = true
            setOnClickListener { onOpenMacros?.invoke() }
        }
        chipsRow.addView(macrosChip, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { marginEnd = Theme.dp(context, Theme.SPACE_XS) })

        // "Ajustes" section button
        val settingsChip = TextView(context).apply {
            text = "⚙ Ajustes"
            textSize = 12f
            setTextColor(Theme.ACCENT) // Brand accent
            val padH = Theme.dp(context, Theme.SPACE_MD); val padV = Theme.dp(context, Theme.SPACE_SM)
            setPadding(padH, padV, padH, padV)
            gravity = Gravity.CENTER
            minimumHeight = Theme.dp(context, 38)
            background = Theme.chipBackground(context)
            isClickable = true
            isFocusable = true
            setOnClickListener {
                onOpenSettings()
            }
        }
        chipsRow.addView(settingsChip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // Close button ✕
        val closeBtn = TextView(context).apply {
            text = "✕"
            textSize = 14f
            setTextColor(0xAAFFFFFF.toInt())
            val padH = Theme.dp(context, Theme.SPACE_SM); val padV = Theme.dp(context, Theme.SPACE_SM)
            setPadding(padH, padV, padH, padV)
            gravity = Gravity.CENTER
            minimumHeight = Theme.dp(context, 38)
            minimumWidth = Theme.dp(context, 38)
            background = Theme.chipBackground(context)
            isClickable = true
            isFocusable = true
            setOnClickListener {
                collapseBar()
            }
        }
        chipsRow.addView(
            closeBtn,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                marginStart = Theme.dp(context, Theme.SPACE_XS)
            }
        )

        scroll.addView(chipsRow)
        topBarContainer.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // Add views to this container
        addView(
            topBarContainer,
            LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                topMargin = Theme.dp(context, Theme.SPACE_XS)
            }
        )

        addView(
            floatingTrigger,
            LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                topMargin = Theme.dp(context, Theme.SPACE_XS)
            }
        )

        Theme.applyTypography(this)
        updateChipStyles()
    }

    val barHeight: Int
        get() = if (topBarContainer.height > 0) topBarContainer.bottom else Theme.dp(context, 48)

    fun toggleBar() {
        if (isExpanded) collapseBar() else expandBar()
    }

    fun expandBar() {
        if (isExpanded) return
        isExpanded = true
        floatingTrigger.visibility = View.GONE
        topBarContainer.visibility = View.VISIBLE
        topBarContainer.alpha = 0f
        topBarContainer.translationY = -Theme.dp(context, 40).toFloat()
        topBarContainer.animate()
            .translationY(0f)
            .alpha(1f)
            .setDuration(220)
            .setListener(null)
            .start()

        onBarStateChanged(true)
    }

    fun collapseBar() {
        if (!isExpanded && topBarContainer.visibility != View.VISIBLE) return
        isExpanded = false
        topBarContainer.animate()
            .translationY(-Theme.dp(context, 40).toFloat())
            .alpha(0f)
            .setDuration(180)
            .setListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    topBarContainer.visibility = View.GONE
                    floatingTrigger.visibility = View.VISIBLE
                    floatingTrigger.alpha = 0.50f
                }
            })
            .start()

        onBarStateChanged(false)
    }

    fun setExpandedImmediate(expanded: Boolean) {
        isExpanded = expanded
        if (expanded) {
            floatingTrigger.visibility = View.GONE
            topBarContainer.visibility = View.VISIBLE
            topBarContainer.alpha = 1f
            topBarContainer.translationY = 0f
        } else {
            topBarContainer.visibility = View.GONE
            floatingTrigger.visibility = View.VISIBLE
            floatingTrigger.alpha = 0.50f
        }
        onBarStateChanged(expanded)
    }

    fun setCurrentMode(mode: KbmMode) {
        currentMode = mode
        updateChipStyles()
    }

    fun setAvailableFeatures(kbmAvailable: Boolean, kbmFeatures: Int) {
        for ((mode, chip) in modeChips) {
            if (mode == KbmMode.PAD) {
                chip.visibility = View.VISIBLE
                chip.isEnabled = true
            } else if (!kbmAvailable) {
                chip.visibility = View.GONE
            } else {
                val bit = when (mode) {
                    KbmMode.MOUSE -> AtticPadNative.KBM_FEATURE_MOUSE
                    KbmMode.KEYBOARD -> AtticPadNative.KBM_FEATURE_KEYBOARD
                    KbmMode.MEDIA -> AtticPadNative.KBM_FEATURE_MEDIA
                    else -> 0
                }
                val available = (kbmFeatures and bit) != 0
                chip.visibility = View.VISIBLE
                chip.isEnabled = available
                chip.alpha = if (available) 1.0f else 0.40f
            }
        }
    }

    private fun updateChipStyles() {
        for ((mode, chip) in modeChips) {
            val selected = (mode == currentMode)
            if (selected) {
                chip.setTextColor(Theme.TEXT_PRIMARY)
                chip.background = GradientDrawable().apply {
                    setColor(Theme.SURFACE)
                    cornerRadius = Theme.dp(context, Theme.RADIUS_SM).toFloat()
                    setStroke(Theme.dp(context, 1), Theme.ACCENT)
                }
            } else {
                chip.setTextColor(0xCCFFFFFF.toInt())
                chip.background = Theme.chipBackground(context)
            }
        }
    }

    fun setActiveProfileName(name: String) {
        profileChip?.text = "🎮 $name"
    }
}
