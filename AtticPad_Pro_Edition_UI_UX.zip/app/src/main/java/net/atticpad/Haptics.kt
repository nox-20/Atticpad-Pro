package net.atticpad

import android.content.Context
import android.view.HapticFeedbackConstants
import android.view.View

/**
 * Global haptics preference and feedback helper.
 *
 * Persisted in SharedPreferences ("atticpad", key "haptics_enabled").
 * Defaults to true.
 * Uses performHapticFeedback to respect system user settings.
 */
object Haptics {
    private const val PREFS_NAME = "atticpad"
    private const val KEY_HAPTICS = "haptics_enabled"

    @Volatile
    var isEnabled: Boolean = true
        private set

    fun init(context: Context) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        isEnabled = prefs.getBoolean(KEY_HAPTICS, true)
    }

    fun isEnabled(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        isEnabled = prefs.getBoolean(KEY_HAPTICS, true)
        return isEnabled
    }

    fun setEnabled(context: Context, enabled: Boolean) {
        isEnabled = enabled
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_HAPTICS, enabled)
            .apply()
    }

    fun feedback(view: View, constant: Int = HapticFeedbackConstants.VIRTUAL_KEY) {
        if (isEnabled) {
            view.performHapticFeedback(constant)
        }
    }
}
