package net.atticpad

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.round

/**
 * The touch overlay: virtual sticks, D-pad, face and shoulder buttons, and a
 * touchpad region that forwards raw §5.2 contacts.
 *
 * Implements:
 * - Full customizable controls: move by drag, resize, individual opacity.
 * - Three visual styles: Xbox, PlayStation, Clásico Nintendo.
 * - Editing mode with visual selection ring, handles, and separate controls.
 * - Strict non-interference: while editing == true, applyPlay() is never called,
 *   all inputs are released, and zero packets sent.
 */
class PadView(context: Context) : View(context) {

    var snapshot: InputSnapshot? = null

    /** Called when the hidden L+R+START combo is held (see [comboHoldMs]). */
    var onSelfTestCombo: (() -> Unit)? = null

    var buttonStyle: ButtonStyle = ButtonStyle.NINTENDO
        set(value) {
            field = value
            invalidate()
        }

    /** Visual style property alias */
    var style: ButtonStyle
        get() = buttonStyle
        set(value) { buttonStyle = value }

    fun setEditMode(enable: Boolean) {
        editing = enable
    }

    var selectedControl: PadLayout.Control? = null
        private set

    var onControlSelected: ((PadLayout.Control?) -> Unit)? = null
    var onLayoutModified: (() -> Unit)? = null

    var editing: Boolean = false
        set(value) {
            field = value
            releaseAll()
            snapshot?.setTriggers(InputSnapshot.SRC_TOUCH, 0, 0)
            if (!value) {
                selectedControl = null
                onControlSelected?.invoke(null)
            }
            invalidate()
        }

    var layout: PadLayout = PadLayout.default(PadLayout.Orientation.LANDSCAPE)
        set(value) {
            val isSame = (field === value)
            field = value
            if (!editing && !isSame) {
                selectedControl = null
                onControlSelected?.invoke(null)
            }
            invalidate()
        }

    /** Snap to Grid toggle for edit mode (rounds to nearest 0.02 step for fine precision). */
    var snapToGrid: Boolean = true

    /** Active profile reference to access assigned macros and persistent styles. */
    var activeProfile: PadProfile? = null
        get() = field ?: try {
            ProfileManager.getInstance(context).getActiveProfile()
        } catch (_: Throwable) {
            null
        }

    // --- Macro recording state ---
    var isRecordingMacro: Boolean = false; private set
    val recordedMacroEvents = mutableListOf<MacroEvent>()
    private var lastMacroEventTime: Long = 0L
    private val recordPointerControl = HashMap<Int, PadLayout.Control>()
    private val recordPointerButtonEvents = HashMap<Int, String>()
    private val recordPointerDpadDirs = HashMap<Int, MutableSet<String>>()
    var onMacroEventRecorded: ((Int) -> Unit)? = null

    fun startRecordingMacro() {
        isRecordingMacro = true
        recordedMacroEvents.clear()
        recordPointerControl.clear()
        recordPointerButtonEvents.clear()
        recordPointerDpadDirs.clear()
        lastMacroEventTime = android.os.SystemClock.uptimeMillis()
        invalidate()
    }

    fun stopRecordingMacro(): List<MacroEvent> {
        isRecordingMacro = false
        recordPointerControl.clear()
        recordPointerButtonEvents.clear()
        recordPointerDpadDirs.clear()
        buttons = 0
        knob.clear()
        val result = recordedMacroEvents.toList()
        invalidate()
        return result
    }

    fun cancelRecordingMacro() {
        isRecordingMacro = false
        recordedMacroEvents.clear()
        recordPointerControl.clear()
        recordPointerButtonEvents.clear()
        recordPointerDpadDirs.clear()
        buttons = 0
        knob.clear()
        invalidate()
    }

    // --- Macro playback state ---
    private var macroJob: Job? = null
    var isMacroPlaying: Boolean = false; private set
    var macroStatusText: String? = null; private set
    private var macroActiveControlId: String? = null
    private var macroCurrentButtons: Int = 0
    private var macroTriggerL: Int = 0
    private var macroTriggerR: Int = 0
    private val macroActivePointers = HashSet<Int>()

    fun executeMacro(macro: Macro, control: PadLayout.Control) {
        macroJob?.cancel()
        if (Haptics.isEnabled) {
            performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        }
        isMacroPlaying = true
        macroActiveControlId = control.id
        macroStatusText = "MACRO: ${macro.name}"
        macroCurrentButtons = 0
        macroTriggerL = 0
        macroTriggerR = 0
        invalidate()

        Toast.makeText(context, "⚡ Macro: ${macro.name}", Toast.LENGTH_SHORT).show()

        macroJob = CoroutineScope(Dispatchers.Main).launch {
            try {
                for (event in macro.events) {
                    if (event.delayMs > 0) {
                        delay(event.delayMs)
                    }

                    val bit = if (event.bit != 0) event.bit else getBitForControlId(event.controlId)
                    val isTrigger = event.type == MacroEventType.TRIGGER || isTriggerControl(event.controlId)

                    if (isTrigger) {
                        val pressure = if (event.pressed) {
                            if (event.value > 0) event.value else 32767
                        } else {
                            0
                        }
                        if (event.controlId in listOf("zl", "lt")) {
                            macroTriggerL = pressure
                        } else if (event.controlId in listOf("zr", "rt")) {
                            macroTriggerR = pressure
                        }
                    }

                    if (bit != 0) {
                        macroCurrentButtons = if (event.pressed) {
                            macroCurrentButtons or bit
                        } else {
                            macroCurrentButtons and bit.inv()
                        }
                    }

                    val baseMask = buttons and (control.bit.inv())
                    snapshot?.setButtons(InputSnapshot.SRC_TOUCH, baseMask or macroCurrentButtons)
                    val effL = maxOf(if (baseMask and AtticPadNative.BTN_ZL != 0) 32767 else 0, macroTriggerL)
                    val effR = maxOf(if (baseMask and AtticPadNative.BTN_ZR != 0) 32767 else 0, macroTriggerR)
                    snapshot?.setTriggers(InputSnapshot.SRC_TOUCH, effL, effR)
                    invalidate()
                }
            } finally {
                macroCurrentButtons = 0
                macroTriggerL = 0
                macroTriggerR = 0
                isMacroPlaying = false
                macroActiveControlId = null
                macroStatusText = null
                val baseMask = buttons and (control.bit.inv())
                snapshot?.setButtons(InputSnapshot.SRC_TOUCH, baseMask)
                val effL = if (baseMask and AtticPadNative.BTN_ZL != 0) 32767 else 0
                val effR = if (baseMask and AtticPadNative.BTN_ZR != 0) 32767 else 0
                snapshot?.setTriggers(InputSnapshot.SRC_TOUCH, effL, effR)
                invalidate()
            }
        }
    }

    /**
     * The system-bar / display-cutout insets (px), set by [MainActivity] from
     * `WindowInsets`. Controls are positioned relative to the SAFE rect these
     * carve out of the view.
     */
    var insetLeft = 0; private set
    var insetTop = 0; private set
    var insetRight = 0; private set
    var insetBottom = 0; private set

    fun setInsets(left: Int, top: Int, right: Int, bottom: Int) {
        insetLeft = left; insetTop = top; insetRight = right; insetBottom = bottom
        invalidate()
    }

    private val comboHoldMs = 1200L
    private var comboSince = 0L

    private val density: Float by lazy { context.resources.displayMetrics.density }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Theme.TYPE_BOLD
    }

    private val haloPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
    }

    private val innerBevelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
    }

    private val deadzonePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        pathEffect = DashPathEffect(floatArrayOf(6f, 6f), 0f)
    }

    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val gaugePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val dpadArrowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL_AND_STROKE
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
    }

    private val selectPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 4f
        color = Theme.ACCENT // Shared brand accent
    }

    private val handlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Theme.ACCENT
    }

    /** pointerId -> the control it grabbed. */
    private val grabbed = HashMap<Int, PadLayout.Control>()

    /** Live stick deflection per control id, in view units, for drawing. */
    private val knob = HashMap<String, FloatArray>()
    /** Tracks whether stick is deflected past deadzone for haptics transitions. */
    private val stickDeflected = HashSet<String>()

    private var buttons = 0

    // Edit mode drag tracking
    private var activeEditPointerId = MotionEvent.INVALID_POINTER_ID
    private var isDraggingControl = false
    private var isDraggingHandle = false
    private var isPinching = false
    private var tappedOnEmptySpace = false
    private var editDragOffsetX = 0f
    private var editDragOffsetY = 0f
    private var pinchStartDist = 0f
    private var pinchStartRadius = 0f

    // ---- geometry -------------------------------------------------------

    private fun contentWidth(): Float = max(1f, (width - insetLeft - insetRight).toFloat())
    private fun contentHeight(): Float = max(1f, (height - insetTop - insetBottom).toFloat())
    private fun unit(): Float = min(contentWidth(), contentHeight())
    private fun px(c: PadLayout.Control): Float = insetLeft + c.cx * contentWidth()
    private fun py(c: PadLayout.Control): Float = insetTop + c.cy * contentHeight()
    private fun pr(c: PadLayout.Control): Float = c.r * unit()

    private fun isTrigger(c: PadLayout.Control): Boolean =
        c.kind == PadLayout.Kind.BUTTON && c.id in listOf("l", "zl", "r", "zr")

    private fun controlAt(x: Float, y: Float): PadLayout.Control? {
        // Reverse order so the control drawn last (on top) wins a tie.
        for (i in layout.controls.indices.reversed()) {
            val c = layout.controls[i]
            val r = pr(c)
            val dx = x - px(c)
            val dy = y - py(c)
            val hit = when {
                c.kind == PadLayout.Kind.DPAD || c.kind == PadLayout.Kind.TOUCHPAD -> abs(dx) <= r && abs(dy) <= r
                isTrigger(c) -> abs(dx) <= r * 1.35f && abs(dy) <= r * 0.90f
                c.id in listOf("select", "start", "home", "l3", "r3") -> {
                    val hitR = max(r * 1.35f, Theme.dp(context, 26).toFloat())
                    hypot(dx, dy) <= hitR
                }
                else -> hypot(dx, dy) <= r * 1.15f
            }
            if (hit) return c
        }
        return null
    }

    /**
     * Touch detection for edit mode with generous touch targets (minimum 32dp radius)
     * and priority for the already selected control to avoid accidental switching.
     */
    private fun editControlAt(x: Float, y: Float): PadLayout.Control? {
        val current = selectedControl
        val minTargetR = Theme.dp(context, 32).toFloat()
        // Prioritize the currently selected control if touching within its bounds
        if (current != null) {
            val r = max(pr(current), minTargetR)
            val dx = x - px(current)
            val dy = y - py(current)
            val hit = when {
                current.kind == PadLayout.Kind.DPAD || current.kind == PadLayout.Kind.TOUCHPAD -> abs(dx) <= r && abs(dy) <= r
                isTrigger(current) -> abs(dx) <= max(r * 1.35f, minTargetR) && abs(dy) <= max(r * 0.90f, minTargetR)
                else -> hypot(dx, dy) <= r
            }
            if (hit) return current
        }

        for (i in layout.controls.indices.reversed()) {
            val c = layout.controls[i]
            val r = max(pr(c), minTargetR)
            val dx = x - px(c)
            val dy = y - py(c)
            val hit = when {
                c.kind == PadLayout.Kind.DPAD || c.kind == PadLayout.Kind.TOUCHPAD -> abs(dx) <= r && abs(dy) <= r
                isTrigger(c) -> abs(dx) <= max(r * 1.35f, minTargetR) && abs(dy) <= max(r * 0.90f, minTargetR)
                else -> hypot(dx, dy) <= r
            }
            if (hit) return c
        }
        return null
    }

    private fun isTouchOnResizeHandle(c: PadLayout.Control, x: Float, y: Float): Boolean {
        val cx = px(c)
        val cy = py(c)
        val r = pr(c)
        val handleX = if (isTrigger(c)) cx + r * 1.35f else cx + r
        val handleY = cy
        val handleHitRadius = Theme.dp(context, 24).toFloat()
        return hypot(x - handleX, y - handleY) <= handleHitRadius
    }

    // ---- input ----------------------------------------------------------

    private fun getDpadDirections(c: PadLayout.Control, x: Float, y: Float): Set<String> {
        val dx = x - px(c)
        val dy = y - py(c)
        val r = pr(c)
        val t = r * 0.22f
        val dirs = HashSet<String>()
        if (dy < -t) dirs.add("dpad_up")
        if (dy > t) dirs.add("dpad_down")
        if (dx < -t) dirs.add("dpad_left")
        if (dx > t) dirs.add("dpad_right")
        return dirs
    }

    private fun handleMacroRecordTouch(event: MotionEvent) {
        val now = android.os.SystemClock.uptimeMillis()
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = event.actionIndex
                val pId = event.getPointerId(i)
                val x = event.getX(i); val y = event.getY(i)
                val c = controlAt(x, y)
                if (c != null) {
                    recordPointerControl[pId] = c
                    if (c.kind == PadLayout.Kind.DPAD) {
                        val dirs = getDpadDirections(c, x, y)
                        val activeSet = HashSet<String>()
                        recordPointerDpadDirs[pId] = activeSet
                        for (dir in dirs) {
                            val delay = if (recordedMacroEvents.isEmpty()) 0L else (now - lastMacroEventTime)
                            lastMacroEventTime = now
                            recordedMacroEvents.add(
                                MacroEvent(
                                    controlId = dir,
                                    pressed = true,
                                    delayMs = delay,
                                    type = MacroEventType.BUTTON,
                                    bit = getBitForControlId(dir)
                                )
                            )
                            activeSet.add(dir)
                        }
                        if (Haptics.isEnabled && dirs.isNotEmpty()) {
                            performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                        }
                        onMacroEventRecorded?.invoke(recordedMacroEvents.size)
                    } else if (c.kind == PadLayout.Kind.BUTTON) {
                        val delay = if (recordedMacroEvents.isEmpty()) 0L else (now - lastMacroEventTime)
                        lastMacroEventTime = now
                        val isTrig = isTriggerControl(c.id)
                        val bit = if (c.bit != 0) c.bit else getBitForControlId(c.id)
                        val type = if (isTrig) MacroEventType.TRIGGER else MacroEventType.BUTTON
                        val value = if (isTrig) 32767 else 0
                        recordPointerButtonEvents[pId] = c.id
                        recordedMacroEvents.add(
                            MacroEvent(
                                controlId = c.id,
                                pressed = true,
                                delayMs = delay,
                                type = type,
                                bit = bit,
                                value = value
                            )
                        )
                        if (Haptics.isEnabled) {
                            performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                        }
                        onMacroEventRecorded?.invoke(recordedMacroEvents.size)
                    }
                }
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until event.pointerCount) {
                    val pId = event.getPointerId(i)
                    val c = recordPointerControl[pId] ?: continue
                    if (c.kind == PadLayout.Kind.DPAD) {
                        val newDirs = getDpadDirections(c, event.getX(i), event.getY(i))
                        val currentDirs = recordPointerDpadDirs.getOrPut(pId) { HashSet() }
                        // Press any newly active directions
                        for (dir in newDirs) {
                            if (!currentDirs.contains(dir)) {
                                val delay = now - lastMacroEventTime
                                lastMacroEventTime = now
                                recordedMacroEvents.add(
                                    MacroEvent(
                                        controlId = dir,
                                        pressed = true,
                                        delayMs = delay,
                                        type = MacroEventType.BUTTON,
                                        bit = getBitForControlId(dir)
                                    )
                                )
                                currentDirs.add(dir)
                                onMacroEventRecorded?.invoke(recordedMacroEvents.size)
                            }
                        }
                        // Release directions that left quadrant
                        val toRemove = currentDirs.filter { !newDirs.contains(it) }
                        for (dir in toRemove) {
                            val delay = now - lastMacroEventTime
                            lastMacroEventTime = now
                            recordedMacroEvents.add(
                                MacroEvent(
                                    controlId = dir,
                                    pressed = false,
                                    delayMs = delay,
                                    type = MacroEventType.BUTTON,
                                    bit = getBitForControlId(dir)
                                )
                            )
                            currentDirs.remove(dir)
                            onMacroEventRecorded?.invoke(recordedMacroEvents.size)
                        }
                    } else if (c.kind == PadLayout.Kind.STICK) {
                        var dx = event.getX(i) - px(c)
                        var dy = event.getY(i) - py(c)
                        val r = pr(c)
                        val len = hypot(dx, dy)
                        if (len > r) {
                            dx = dx / len * r
                            dy = dy / len * r
                        }
                        knob[c.id] = floatArrayOf(dx, dy)
                    }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                val pId = event.getPointerId(event.actionIndex)
                val c = recordPointerControl.remove(pId)
                val recordedCtrlId = recordPointerButtonEvents.remove(pId)
                val dpadDirs = recordPointerDpadDirs.remove(pId)

                if (dpadDirs != null) {
                    for (dir in dpadDirs) {
                        val delay = now - lastMacroEventTime
                        lastMacroEventTime = now
                        recordedMacroEvents.add(
                            MacroEvent(
                                controlId = dir,
                                pressed = false,
                                delayMs = delay,
                                type = MacroEventType.BUTTON,
                                bit = getBitForControlId(dir)
                            )
                        )
                        onMacroEventRecorded?.invoke(recordedMacroEvents.size)
                    }
                } else if (c != null && c.kind == PadLayout.Kind.BUTTON) {
                    val ctrlId = recordedCtrlId ?: c.id
                    val delay = now - lastMacroEventTime
                    lastMacroEventTime = now
                    val isTrig = isTriggerControl(ctrlId)
                    val bit = if (c.bit != 0) c.bit else getBitForControlId(ctrlId)
                    recordedMacroEvents.add(
                        MacroEvent(
                            controlId = ctrlId,
                            pressed = false,
                            delayMs = delay,
                            type = if (isTrig) MacroEventType.TRIGGER else MacroEventType.BUTTON,
                            bit = bit,
                            value = 0
                        )
                    )
                    onMacroEventRecorded?.invoke(recordedMacroEvents.size)
                } else if (c != null && c.kind == PadLayout.Kind.STICK) {
                    knob.remove(c.id)
                }
            }
            MotionEvent.ACTION_CANCEL -> {
                for ((_, dpadDirs) in recordPointerDpadDirs) {
                    for (dir in dpadDirs) {
                        val delay = now - lastMacroEventTime
                        lastMacroEventTime = now
                        recordedMacroEvents.add(
                            MacroEvent(
                                controlId = dir,
                                pressed = false,
                                delayMs = delay,
                                type = MacroEventType.BUTTON,
                                bit = getBitForControlId(dir)
                            )
                        )
                    }
                }
                recordPointerDpadDirs.clear()

                for ((_, ctrlId) in recordPointerButtonEvents) {
                    val delay = now - lastMacroEventTime
                    lastMacroEventTime = now
                    val isTrig = isTriggerControl(ctrlId)
                    recordedMacroEvents.add(
                        MacroEvent(
                            controlId = ctrlId,
                            pressed = false,
                            delayMs = delay,
                            type = if (isTrig) MacroEventType.TRIGGER else MacroEventType.BUTTON,
                            bit = getBitForControlId(ctrlId),
                            value = 0
                        )
                    )
                }
                recordPointerButtonEvents.clear()
                recordPointerControl.clear()
                knob.clear()
                onMacroEventRecorded?.invoke(recordedMacroEvents.size)
            }
        }

        // Calculate visual button mask for feedback without network transmission
        var mask = 0
        for (i in 0 until event.pointerCount) {
            val pId = event.getPointerId(i)
            if (event.actionMasked == MotionEvent.ACTION_POINTER_UP && i == event.actionIndex) continue
            val c = recordPointerControl[pId] ?: continue
            if (c.kind == PadLayout.Kind.BUTTON) {
                mask = mask or (if (c.bit != 0) c.bit else getBitForControlId(c.id))
            } else if (c.kind == PadLayout.Kind.DPAD) {
                val dirs = recordPointerDpadDirs[pId] ?: emptySet()
                for (dir in dirs) {
                    mask = mask or getBitForControlId(dir)
                }
            }
        }
        buttons = mask
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (isRecordingMacro) {
            handleMacroRecordTouch(event)
            invalidate()
            return true
        }

        if (editing) {
            handleEditTouch(event)
            invalidate()
            return true
        }

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = event.actionIndex
                val pId = event.getPointerId(i)
                val c = controlAt(event.getX(i), event.getY(i))
                if (c != null) {
                    val macro = if (!c.macroId.isNullOrEmpty()) {
                        MacroManager.getInstance(context).getMacro(c.macroId!!)
                    } else {
                        activeProfile?.macros?.get(c.id)
                    }
                    if (macro != null && c.kind == PadLayout.Kind.BUTTON) {
                        macroActivePointers.add(pId)
                        executeMacro(macro, c)
                        return true
                    }
                    grabbed[pId] = c
                    if (Haptics.isEnabled) {
                        when (c.kind) {
                            PadLayout.Kind.BUTTON, PadLayout.Kind.DPAD -> {
                                performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                            }
                            else -> {}
                        }
                    }
                }
            }

            MotionEvent.ACTION_MOVE -> {
                if (Haptics.isEnabled) {
                    for (i in 0 until event.pointerCount) {
                        val id = event.getPointerId(i)
                        val c = grabbed[id] ?: continue
                        if (c.kind == PadLayout.Kind.STICK) {
                            val dx = event.getX(i) - px(c)
                            val dy = event.getY(i) - py(c)
                            val r = pr(c)
                            val deadzone = r * 0.20f
                            val isDeflected = hypot(dx, dy) > deadzone
                            val wasDeflected = stickDeflected.contains(c.id)
                            if (!wasDeflected && isDeflected) {
                                stickDeflected.add(c.id)
                                performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                            } else if (wasDeflected && !isDeflected) {
                                stickDeflected.remove(c.id)
                            }
                        }
                    }
                }
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP,
            MotionEvent.ACTION_CANCEL -> {
                val id = event.getPointerId(event.actionIndex)
                if (macroActivePointers.remove(id)) {
                    if (event.actionMasked == MotionEvent.ACTION_CANCEL) releaseAll()
                    invalidate()
                    return true
                }
                grabbed.remove(id)?.let {
                    knob.remove(it.id)
                    stickDeflected.remove(it.id)
                }
                if (event.actionMasked == MotionEvent.ACTION_CANCEL) releaseAll()
            }
        }

        applyPlay(event)
        invalidate()
        return true
    }

    private fun handleEditTouch(event: MotionEvent) {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val x = event.x
                val y = event.y
                activeEditPointerId = event.getPointerId(0)

                val current = selectedControl
                if (current != null && isTouchOnResizeHandle(current, x, y)) {
                    isDraggingHandle = true
                    isDraggingControl = false
                    isPinching = false
                    tappedOnEmptySpace = false
                } else {
                    val hit = editControlAt(x, y)
                    if (hit != null) {
                        selectedControl = hit
                        onControlSelected?.invoke(hit)
                        editDragOffsetX = x - px(hit)
                        editDragOffsetY = y - py(hit)
                        isDraggingControl = true
                        isDraggingHandle = false
                        isPinching = false
                        tappedOnEmptySpace = false
                    } else {
                        // Tapped empty space; don't clear selection until ACTION_UP confirms tap was outside
                        isDraggingControl = false
                        isDraggingHandle = false
                        isPinching = false
                        tappedOnEmptySpace = true
                    }
                }
            }

            MotionEvent.ACTION_POINTER_DOWN -> {
                if (event.pointerCount >= 2 && selectedControl != null) {
                    val x1 = event.getX(0); val y1 = event.getY(0)
                    val x2 = event.getX(1); val y2 = event.getY(1)
                    pinchStartDist = hypot(x1 - x2, y1 - y2)
                    pinchStartRadius = selectedControl?.r ?: 0.06f
                    if (pinchStartDist > 20f) {
                        isPinching = true
                        isDraggingControl = false
                        isDraggingHandle = false
                    }
                }
            }

            MotionEvent.ACTION_MOVE -> {
                val current = selectedControl ?: return

                if (isPinching && event.pointerCount >= 2 && pinchStartDist > 20f) {
                    val x1 = event.getX(0); val y1 = event.getY(0)
                    val x2 = event.getX(1); val y2 = event.getY(1)
                    val currentDist = hypot(x1 - x2, y1 - y2)
                    val scale = currentDist / pinchStartDist
                    current.r = (pinchStartRadius * scale).coerceIn(0.025f, 0.35f)
                    onLayoutModified?.invoke()
                } else if (isDraggingHandle) {
                    val pIndex = event.findPointerIndex(activeEditPointerId)
                    val hx = if (pIndex >= 0) event.getX(pIndex) else event.x
                    val hy = if (pIndex >= 0) event.getY(pIndex) else event.y
                    val cx = px(current)
                    val cy = py(current)
                    val dist = hypot(hx - cx, hy - cy)
                    current.r = (dist / unit()).coerceIn(0.025f, 0.35f)
                    onLayoutModified?.invoke()
                } else if (isDraggingControl) {
                    val pIndex = event.findPointerIndex(activeEditPointerId)
                    if (pIndex >= 0) {
                        val curX = event.getX(pIndex)
                        val curY = event.getY(pIndex)
                        val targetX = curX - editDragOffsetX
                        val targetY = curY - editDragOffsetY

                        val cW = contentWidth()
                        val cH = contentHeight()
                        val rPx = pr(current)
                        val minXNorm = (rPx / cW).coerceIn(0.015f, 0.40f)
                        val maxXNorm = 1f - minXNorm
                        val minYNorm = (rPx / cH).coerceIn(0.015f, 0.40f)
                        val maxYNorm = 1f - minYNorm

                        var newCx = ((targetX - insetLeft) / cW).coerceIn(minXNorm, maxXNorm)
                        var newCy = ((targetY - insetTop) / cH).coerceIn(minYNorm, maxYNorm)

                        if (snapToGrid) {
                            newCx = (round(newCx / 0.02f) * 0.02f).coerceIn(minXNorm, maxXNorm)
                            newCy = (round(newCy / 0.02f) * 0.02f).coerceIn(minYNorm, maxYNorm)
                        }

                        current.cx = newCx
                        current.cy = newCy
                        onLayoutModified?.invoke()
                    }
                }
            }

            MotionEvent.ACTION_POINTER_UP -> {
                val pointerIndex = event.actionIndex
                val pointerId = event.getPointerId(pointerIndex)

                if (isPinching) {
                    isPinching = false
                    val remainingIndex = if (pointerIndex == 0) 1 else 0
                    if (remainingIndex < event.pointerCount) {
                        activeEditPointerId = event.getPointerId(remainingIndex)
                        val current = selectedControl
                        if (current != null) {
                            editDragOffsetX = event.getX(remainingIndex) - px(current)
                            editDragOffsetY = event.getY(remainingIndex) - py(current)
                            isDraggingControl = true
                        }
                    }
                } else if (pointerId == activeEditPointerId) {
                    val newIndex = if (pointerIndex == 0) 1 else 0
                    if (newIndex < event.pointerCount) {
                        activeEditPointerId = event.getPointerId(newIndex)
                        val current = selectedControl
                        if (current != null) {
                            editDragOffsetX = event.getX(newIndex) - px(current)
                            editDragOffsetY = event.getY(newIndex) - py(current)
                        }
                    }
                }
            }

            MotionEvent.ACTION_UP -> {
                if (tappedOnEmptySpace && !isDraggingControl && !isDraggingHandle && !isPinching) {
                    // Tap on empty space: clear selection only if up is also outside any control
                    val hit = editControlAt(event.x, event.y)
                    if (hit == null) {
                        selectedControl = null
                        onControlSelected?.invoke(null)
                    }
                }
                isDraggingControl = false
                isDraggingHandle = false
                isPinching = false
                tappedOnEmptySpace = false
                activeEditPointerId = MotionEvent.INVALID_POINTER_ID
            }

            MotionEvent.ACTION_CANCEL -> {
                isDraggingControl = false
                isDraggingHandle = false
                isPinching = false
                tappedOnEmptySpace = false
                activeEditPointerId = MotionEvent.INVALID_POINTER_ID
            }
        }
    }

    fun selectControl(control: PadLayout.Control?) {
        selectedControl = control
        onControlSelected?.invoke(control)
        invalidate()
    }

    /**
     * Removes the currently selected control from the active layout with strict safeguards:
     * - Essential system buttons (select, start, home) cannot be removed.
     * - At least 1 joystick must remain.
     * - At least 2 action buttons (a, b, x, y) must remain.
     */
    fun removeSelectedControl(): Boolean {
        val target = selectedControl ?: return false

        // Essential controls protection
        if (target.id in listOf("select", "start", "home")) {
            Toast.makeText(context, "No se pueden eliminar los controles esenciales (Select, Start, Home)", Toast.LENGTH_SHORT).show()
            return false
        }

        // Action buttons protection: at least 2 must remain
        if (target.id in listOf("a", "b", "x", "y")) {
            val actionCount = layout.controls.count { it.id in listOf("a", "b", "x", "y") }
            if (actionCount <= 2) {
                Toast.makeText(context, "Debe quedar al menos un joystick y dos botones de acción", Toast.LENGTH_SHORT).show()
                return false
            }
        }

        // Joysticks protection: at least 1 must remain
        if (target.kind == PadLayout.Kind.STICK) {
            val stickCount = layout.controls.count { it.kind == PadLayout.Kind.STICK }
            if (stickCount <= 1) {
                Toast.makeText(context, "Debe quedar al menos un joystick y dos botones de acción", Toast.LENGTH_SHORT).show()
                return false
            }
        }

        layout.controls.remove(target)
        selectedControl = null
        onControlSelected?.invoke(null)
        onLayoutModified?.invoke()
        invalidate()
        return true
    }

    fun nudgeSelected(dxNorm: Float, dyNorm: Float) {
        val c = selectedControl ?: return
        c.cx = (c.cx + dxNorm).coerceIn(0.02f, 0.98f)
        c.cy = (c.cy + dyNorm).coerceIn(0.02f, 0.98f)
        onLayoutModified?.invoke()
        invalidate()
    }

    fun setSelectedRadius(newR: Float) {
        val c = selectedControl ?: return
        c.r = newR.coerceIn(0.025f, 0.35f)
        onLayoutModified?.invoke()
        invalidate()
    }

    fun setSelectedOpacity(newOpacity: Float) {
        val c = selectedControl ?: return
        c.opacity = newOpacity.coerceIn(0.1f, 1.0f)
        onLayoutModified?.invoke()
        invalidate()
    }

    fun adjustActionSpread(factor: Float) {
        layout.adjustActionButtonsSpread(factor)
        onLayoutModified?.invoke()
        invalidate()
    }

    fun resetCurrentOrientation(orientation: PadLayout.Orientation) {
        layout = PadLayout.default(orientation)
        selectedControl = null
        onControlSelected?.invoke(null)
        onLayoutModified?.invoke()
        invalidate()
    }

    fun releaseAll() {
        macroJob?.cancel()
        macroJob = null
        macroActivePointers.clear()
        macroCurrentButtons = 0
        macroTriggerL = 0
        macroTriggerR = 0
        isMacroPlaying = false
        macroActiveControlId = null
        macroStatusText = null

        grabbed.clear()
        knob.clear()
        stickDeflected.clear()
        buttons = 0
        comboSince = 0L
        snapshot?.setButtons(InputSnapshot.SRC_TOUCH, 0)
        snapshot?.setTriggers(InputSnapshot.SRC_TOUCH, 0, 0)
        snapshot?.setSticks(InputSnapshot.SRC_TOUCH, 0, 0, 0, 0)
        snapshot?.setTouches(0, 0, 0, 0, 0, 0, 0, 0, 0)
    }

    private fun applyPlay(event: MotionEvent) {
        val s = snapshot ?: return

        var mask = 0
        var lx = 0; var ly = 0; var rx = 0; var ry = 0
        knob.clear()

        // §5.2 carries at most two contacts, and only from the touchpad.
        var tn = 0
        val tid = IntArray(2); val tpr = IntArray(2)
        val tx = IntArray(2); val ty = IntArray(2)

        for (i in 0 until event.pointerCount) {
            val id = event.getPointerId(i)
            val c = grabbed[id] ?: continue
            // A pointer that has been lifted is still in the event; skip it.
            if (event.actionMasked == MotionEvent.ACTION_POINTER_UP &&
                i == event.actionIndex
            ) continue

            val x = event.getX(i)
            val y = event.getY(i)
            val r = pr(c)
            var dx = x - px(c)
            var dy = y - py(c)

            when (c.kind) {
                PadLayout.Kind.BUTTON -> {
                    if (c.id != macroActiveControlId) {
                        mask = mask or c.bit
                    }
                }

                PadLayout.Kind.DPAD -> {
                    val t = r * 0.30f
                    if (dy < -t) mask = mask or AtticPadNative.BTN_DPAD_UP
                    if (dy > t) mask = mask or AtticPadNative.BTN_DPAD_DOWN
                    if (dx < -t) mask = mask or AtticPadNative.BTN_DPAD_LEFT
                    if (dx > t) mask = mask or AtticPadNative.BTN_DPAD_RIGHT
                }

                PadLayout.Kind.STICK -> {
                    val len = hypot(dx, dy)
                    if (len > r) {
                        dx = dx / len * r
                        dy = dy / len * r
                    }
                    knob[c.id] = floatArrayOf(dx, dy)
                    val vx = (dx / r * 32767f).toInt().coerceIn(-32768, 32767)
                    // +Y UP on the wire (§5.3); the screen's +Y is down.
                    val vy = (-dy / r * 32767f).toInt().coerceIn(-32768, 32767)
                    if (c.stick == 0) { lx = vx; ly = vy } else { rx = vx; ry = vy }
                }

                PadLayout.Kind.TOUCHPAD -> {
                    if (tn < 2) {
                        tid[tn] = id and 0xFF
                        tpr[tn] = 0
                        tx[tn] = ((x - px(c)) / r * 32767f).toInt().coerceIn(-32768, 32767)
                        ty[tn] = ((y - py(c)) / r * 32767f).toInt().coerceIn(-32768, 32767)
                        tn++
                    }
                    mask = mask or AtticPadNative.BTN_TOUCH_PRESS
                }
            }
        }

        buttons = mask
        s.setButtons(InputSnapshot.SRC_TOUCH, if (isMacroPlaying) (mask or macroCurrentButtons) else mask)
        s.setSticks(InputSnapshot.SRC_TOUCH, lx, ly, rx, ry)

        val effL = maxOf(if (mask and AtticPadNative.BTN_ZL != 0) 32767 else 0, if (isMacroPlaying) macroTriggerL else 0)
        val effR = maxOf(if (mask and AtticPadNative.BTN_ZR != 0) 32767 else 0, if (isMacroPlaying) macroTriggerR else 0)
        s.setTriggers(InputSnapshot.SRC_TOUCH, effL, effR)
        s.setTouches(tn, tid[0], tpr[0], tx[0], ty[0], tid[1], tpr[1], tx[1], ty[1])

        checkCombo(mask)
    }

    private fun checkCombo(mask: Int) {
        val want = AtticPadNative.BTN_L or AtticPadNative.BTN_R or AtticPadNative.BTN_START
        if (mask and want == want) {
            val now = System.currentTimeMillis()
            if (comboSince == 0L) {
                comboSince = now
            } else if (now - comboSince >= comboHoldMs) {
                comboSince = 0L
                onSelfTestCombo?.invoke()
            }
        } else {
            comboSince = 0L
        }
    }

    // ---- drawing --------------------------------------------------------

    private fun applyColorWithAlpha(baseColor: Int, alphaRatio: Float, controlOpacity: Float): Int {
        val a = ((Color.alpha(baseColor) / 255f) * alphaRatio * controlOpacity * 255f).toInt().coerceIn(0, 255)
        return (baseColor and 0x00FFFFFF) or (a shl 24)
    }

    private val triggerRect = RectF()
    private val triggerHaloRect = RectF()
    private val dpadArrowPath = Path()

    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x26FFFFFF // fine semi-transparent (15% white)
        strokeWidth = 1f
        style = Paint.Style.STROKE
    }
    private val gridCenterPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = applyColorWithAlpha(Theme.ACCENT, 0.50f, 1.0f) // shared brand accent
        strokeWidth = 1.5f
        style = Paint.Style.STROKE
    }

    private fun drawGrid(canvas: Canvas) {
        val cW = contentWidth()
        val cH = contentHeight()
        val left = insetLeft.toFloat()
        val right = insetLeft + cW
        val top = insetTop.toFloat()
        val bottom = insetTop + cH

        // Vertical lines every 0.1
        for (i in 1..9) {
            val gx = left + (i * 0.1f) * cW
            val isCenter = (i == 5)
            canvas.drawLine(gx, top, gx, bottom, if (isCenter) gridCenterPaint else gridPaint)
        }

        // Horizontal lines every 0.1
        for (i in 1..9) {
            val gy = top + (i * 0.1f) * cH
            val isCenter = (i == 5)
            canvas.drawLine(left, gy, right, gy, if (isCenter) gridCenterPaint else gridPaint)
        }
    }

    private fun drawMacroBadge(canvas: Canvas, x: Float, y: Float, r: Float, op: Float) {
        val badgeR = 6f * density
        val badgeX = x + r * 0.70f
        val badgeY = y - r * 0.70f
        val badgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = applyColorWithAlpha(Theme.ACCENT, 0.90f, op)
            style = Paint.Style.FILL
        }
        canvas.drawCircle(badgeX, badgeY, badgeR, badgePaint)
        val textP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = 8f * density
            typeface = Theme.TYPE_BOLD
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("M", badgeX, badgeY + 3f * density, textP)
    }

    private fun drawMacroStatusBanner(canvas: Canvas) {
        val bannerText = macroStatusText ?: "MACRO"
        val bannerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 13f * density
            typeface = Theme.TYPE_BOLD
            textAlign = Paint.Align.CENTER
        }
        val textW = bannerPaint.measureText(bannerText)
        val padH = 14f * density
        val padV = 5f * density
        val bannerW = textW + padH * 2
        val bannerH = 22f * density + padV
        val left = (width - bannerW) / 2f
        val top = insetTop + 8f * density
        val rect = RectF(left, top, left + bannerW, top + bannerH)

        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xEE161A22.toInt()
            style = Paint.Style.FILL
        }
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Theme.ACCENT
            style = Paint.Style.STROKE
            strokeWidth = 1.5f * density
        }
        canvas.drawRoundRect(rect, 8f * density, 8f * density, bgPaint)
        canvas.drawRoundRect(rect, 8f * density, 8f * density, borderPaint)
        canvas.drawText(bannerText, width / 2f, top + 16f * density, bannerPaint)
    }

    override fun onDraw(canvas: Canvas) {
        val u = unit()
        text.textSize = u * 0.045f

        // When editing == true, draw subtle background grid and cyan crosshair
        if (editing) {
            drawGrid(canvas)
        }

        for (c in layout.controls) {
            val x = px(c)
            val y = py(c)
            val r = pr(c)
            val active = when (c.kind) {
                PadLayout.Kind.BUTTON -> (c.bit != 0 && (buttons and c.bit) != 0) ||
                        (c.bit != 0 && (macroCurrentButtons and c.bit) != 0) ||
                        (isMacroPlaying && macroActiveControlId == c.id) ||
                        recordPointerControl.values.contains(c)
                else -> knob.containsKey(c.id) || grabbed.values.contains(c) || recordPointerControl.values.contains(c)
            }
            val op = c.opacity.coerceIn(0.1f, 1.0f)

            when (c.kind) {
                PadLayout.Kind.STICK -> drawStick(canvas, c, x, y, r, active, op)
                PadLayout.Kind.DPAD -> drawDpad(canvas, x, y, r, op)
                PadLayout.Kind.TOUCHPAD -> drawTouchpad(canvas, c, x, y, r, active, op)
                PadLayout.Kind.BUTTON -> {
                    if (!c.macroId.isNullOrEmpty() || c.id.startsWith("macro_")) {
                        drawMacroButton(canvas, c, x, y, r, active, op)
                    } else if (isTrigger(c)) {
                        drawTriggerButton(canvas, c, x, y, r, active, op)
                    } else if (c.id in listOf("a", "b", "x", "y")) {
                        drawActionButton(canvas, c, x, y, r, active, op)
                    } else {
                        drawGenericButton(canvas, c, x, y, r, active, op)
                    }
                    if (activeProfile?.macros?.containsKey(c.id) == true) {
                        drawMacroBadge(canvas, x, y, r, op)
                    }
                }
            }

            // Selection and edit highlights
            if (editing) {
                drawEditHighlight(canvas, c, x, y, r, u)
            }
        }

        // Visual feedback banner while macro is executing
        if (isMacroPlaying && macroStatusText != null) {
            drawMacroStatusBanner(canvas)
        }
    }

    private fun drawActionButton(
        canvas: Canvas,
        c: PadLayout.Control,
        x: Float,
        y: Float,
        r: Float,
        active: Boolean,
        opacity: Float
    ) {
        val visual = VisualTheme.getVisual(c.id, buttonStyle, active)

        // Visual sinking on press: apparent radius reduced by 1.5dp and center shifted down slightly
        val sink = if (active) 1.5f * density else 0f
        val drawY = y + sink
        val drawR = if (active) max(4f, r - 1.5f * density) else r

        // 1. Halo exterior (~2-3dp) when active
        if (active) {
            haloPaint.color = applyColorWithAlpha(visual.strokeColor, 0.45f, opacity)
            haloPaint.strokeWidth = 3f * density
            canvas.drawCircle(x, y, r + 2.5f * density, haloPaint)
        }

        // 2. Subtle radial gradient inside the circle (center brighter by ~15%, edge darker)
        // Inverted when active (center darker, edge brighter)
        val baseColor = visual.fillColor
        val centerColor = if (active) {
            VisualTheme.adjustLightness(baseColor, 0.82f)
        } else {
            VisualTheme.adjustLightness(baseColor, 1.15f)
        }
        val edgeColor = if (active) {
            VisualTheme.adjustLightness(baseColor, 1.15f)
        } else {
            VisualTheme.adjustLightness(baseColor, 0.85f)
        }

        val gradCenterY = if (active) drawY + drawR * 0.15f else drawY - drawR * 0.15f
        fill.shader = RadialGradient(
            x, gradCenterY, drawR,
            applyColorWithAlpha(centerColor, 1.0f, opacity),
            applyColorWithAlpha(edgeColor, 1.0f, opacity),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(x, drawY, drawR, fill)
        fill.shader = null

        // 3. Inner border (1-2dp) with darker color for depth/bevel
        innerBevelPaint.strokeWidth = 1.5f * density
        val bevelColor = if (active) 0x66000000 else 0x33000000
        innerBevelPaint.color = applyColorWithAlpha(bevelColor, 1.0f, opacity)
        canvas.drawCircle(x, drawY, max(2f, drawR - 1.2f * density), innerBevelPaint)

        // 4. Outer rim stroke
        stroke.color = applyColorWithAlpha(visual.strokeColor, 1.0f, opacity)
        stroke.strokeWidth = if (buttonStyle == ButtonStyle.NINTENDO) 2.5f * density else 3.5f * density
        canvas.drawCircle(x, drawY, drawR, stroke)

        // 5. Symbol or letter optically centered
        if (visual.symbol != SymbolType.NONE) {
            val symbolColor = if (active) Color.WHITE else visual.strokeColor
            VisualTheme.drawSymbol(
                canvas = canvas,
                symbol = visual.symbol,
                cx = x,
                cy = drawY,
                radius = drawR,
                color = symbolColor,
                strokeWidth = max(3.5f * density, drawR * 0.15f),
                alphaMultiplier = opacity
            )
        } else {
            text.color = applyColorWithAlpha(visual.textColor, 1.0f, opacity)
            val ts = min(unit() * 0.055f, drawR * 0.90f)
            text.textSize = ts
            // Optical center adjustment: letters like "A" have higher optical center of mass
            val opticalY = drawY + ts * 0.32f - drawR * 0.02f
            val labelToDraw = visual.label.ifEmpty { c.label }
            canvas.drawText(labelToDraw, x, opticalY, text)
        }
    }

    private fun drawTriggerButton(
        canvas: Canvas,
        c: PadLayout.Control,
        x: Float,
        y: Float,
        r: Float,
        active: Boolean,
        opacity: Float
    ) {
        val halfW = r * 1.35f
        val halfH = r * 0.85f
        val corner = halfH * 0.42f
        val sink = if (active) 1.5f * density else 0f
        val drawY = y + sink

        triggerRect.set(x - halfW, drawY - halfH, x + halfW, drawY + halfH)

        // 1. Halo when active
        if (active) {
            val haloMargin = 2.5f * density
            triggerHaloRect.set(
                triggerRect.left - haloMargin,
                triggerRect.top - haloMargin,
                triggerRect.right + haloMargin,
                triggerRect.bottom + haloMargin
            )
            haloPaint.color = applyColorWithAlpha(Theme.ACCENT, 0.40f, opacity)
            haloPaint.strokeWidth = 2.5f * density
            canvas.drawRoundRect(triggerHaloRect, corner + haloMargin, corner + haloMargin, haloPaint)
        }

        // 2. Subtle horizontal/vertical gradient: curved bumper/trigger profile
        val topColor = if (active) 0xFF4A566E.toInt() else 0xFF2A303D.toInt()
        val bottomColor = if (active) Theme.SURFACE else 0xFF14171E.toInt()
        fill.shader = LinearGradient(
            x, triggerRect.top, x, triggerRect.bottom,
            applyColorWithAlpha(topColor, 1.0f, opacity),
            applyColorWithAlpha(bottomColor, 1.0f, opacity),
            Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(triggerRect, corner, corner, fill)
        fill.shader = null

        // 3. Pressure gauge indicator for analog triggers (zl, zr)
        val isAnalogTrigger = c.id in listOf("zl", "zr")
        if (isAnalogTrigger && active) {
            val gaugeH = triggerRect.height() * 0.45f
            val gaugeRect = RectF(
                triggerRect.left + 2f * density,
                triggerRect.bottom - gaugeH,
                triggerRect.right - 2f * density,
                triggerRect.bottom - 2f * density
            )
            gaugePaint.color = applyColorWithAlpha(Theme.ACCENT, 0.65f, opacity)
            canvas.drawRoundRect(gaugeRect, corner * 0.5f, corner * 0.5f, gaugePaint)
        }

        // 4. Inner bevel and outer rim
        innerBevelPaint.strokeWidth = 1.2f * density
        innerBevelPaint.color = applyColorWithAlpha(if (active) 0x55FFFFFF else 0x22FFFFFF, 1.0f, opacity)
        val insetBevel = 1.2f * density
        val innerRect = RectF(
            triggerRect.left + insetBevel, triggerRect.top + insetBevel,
            triggerRect.right - insetBevel, triggerRect.bottom - insetBevel
        )
        canvas.drawRoundRect(innerRect, corner - insetBevel, corner - insetBevel, innerBevelPaint)

        stroke.color = applyColorWithAlpha(if (active) Theme.ACCENT else 0x80FFFFFF.toInt(), 1.0f, opacity)
        stroke.strokeWidth = if (active) 2.5f * density else 1.8f * density
        canvas.drawRoundRect(triggerRect, corner, corner, stroke)

        // 5. Label text
        text.color = applyColorWithAlpha(if (active) Color.WHITE else 0xCCFFFFFF.toInt(), 1.0f, opacity)
        val ts = min(unit() * 0.045f, halfH * 0.85f)
        text.textSize = ts
        val opticalY = drawY + ts * 0.35f
        canvas.drawText(c.label, x, opticalY, text)
    }

    private fun drawStick(
        canvas: Canvas,
        c: PadLayout.Control,
        x: Float,
        y: Float,
        r: Float,
        active: Boolean,
        opacity: Float
    ) {
        // 1. Outer socket / well with linear gradient (top light, bottom shadow for 3D depth)
        val topCavity = 0xFF2A313E.toInt()
        val bottomCavity = 0xFF12141A.toInt()
        fill.shader = LinearGradient(
            x, y - r, x, y + r,
            applyColorWithAlpha(topCavity, 1.0f, opacity),
            applyColorWithAlpha(bottomCavity, 1.0f, opacity),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(x, y, r, fill)
        fill.shader = null

        // Cavity rim
        stroke.color = applyColorWithAlpha(0x66FFFFFF, 1.0f, opacity)
        stroke.strokeWidth = 2f * density
        canvas.drawCircle(x, y, r, stroke)

        // Inner bevel cavity shadow
        innerBevelPaint.strokeWidth = 1.5f * density
        innerBevelPaint.color = applyColorWithAlpha(0x66000000, 1.0f, opacity)
        canvas.drawCircle(x, y, max(2f, r - 1.5f * density), innerBevelPaint)

        // 2. Deadzone indicator: dotted ring at deadzone radius (r * 0.20f)
        // Only visible while dragging / active, fades upon release
        val isDeflected = knob.containsKey(c.id) || active
        if (isDeflected) {
            deadzonePaint.strokeWidth = 1.2f * density
            deadzonePaint.color = applyColorWithAlpha(Theme.ACCENT, 0.55f, opacity)
            canvas.drawCircle(x, y, r * 0.20f, deadzonePaint)
        }

        // 3. Thumbstick knob
        val k = knob[c.id]
        val kx = x + (k?.get(0) ?: 0f)
        val ky = y + (k?.get(1) ?: 0f)
        val kr = r * 0.42f

        // Drop shadow under knob
        shadowPaint.color = applyColorWithAlpha(0x80000000.toInt(), 1.0f, opacity)
        canvas.drawCircle(kx, ky + 2.5f * density, kr * 1.05f, shadowPaint)

        // Active halo on knob
        if (active) {
            haloPaint.color = applyColorWithAlpha(Theme.ACCENT, 0.40f, opacity)
            haloPaint.strokeWidth = 2.5f * density
            canvas.drawCircle(kx, ky, kr + 2.5f * density, haloPaint)
        }

        // Knob cap radial gradient (simulating top-left light source highlight)
        val knobLight = if (active) 0xFF5D6B82.toInt() else 0xFF4A5568.toInt()
        val knobDark = if (active) 0xFF222732.toInt() else 0xFF191D24.toInt()
        fill.shader = RadialGradient(
            kx - kr * 0.25f, ky - kr * 0.25f, kr,
            applyColorWithAlpha(knobLight, 1.0f, opacity),
            applyColorWithAlpha(knobDark, 1.0f, opacity),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(kx, ky, kr, fill)
        fill.shader = null

        // Knob concentric textured grip ring
        stroke.color = applyColorWithAlpha(0xFF101217.toInt(), 0.85f, opacity)
        stroke.strokeWidth = 1.5f * density
        canvas.drawCircle(kx, ky, kr * 0.50f, stroke)

        innerBevelPaint.color = applyColorWithAlpha(0x33FFFFFF, 1.0f, opacity)
        innerBevelPaint.strokeWidth = 1f * density
        canvas.drawCircle(kx, ky, kr * 0.50f + 1f * density, innerBevelPaint)

        // Knob outer rim
        stroke.color = applyColorWithAlpha(if (active) Theme.ACCENT else 0x99FFFFFF.toInt(), 1.0f, opacity)
        stroke.strokeWidth = 2f * density
        canvas.drawCircle(kx, ky, kr, stroke)
    }

    private fun drawDpad(canvas: Canvas, x: Float, y: Float, r: Float, opacity: Float) {
        val arm = r * 0.36f
        val corner = arm * 0.35f

        val upActive = (buttons and AtticPadNative.BTN_DPAD_UP) != 0
        val downActive = (buttons and AtticPadNative.BTN_DPAD_DOWN) != 0
        val leftActive = (buttons and AtticPadNative.BTN_DPAD_LEFT) != 0
        val rightActive = (buttons and AtticPadNative.BTN_DPAD_RIGHT) != 0

        // 1. Arms drawing with distinct pressed state
        val northRect = RectF(x - arm, y - r, x + arm, y)
        val southRect = RectF(x - arm, y, x + arm, y + r)
        val westRect = RectF(x - r, y - arm, x, y + arm)
        val eastRect = RectF(x, y - arm, x + r, y + arm)

        fun drawArm(rect: RectF, isActive: Boolean) {
            val baseColor = if (isActive) 0xFF424D61.toInt() else 0xFF222731.toInt()
            fill.color = applyColorWithAlpha(baseColor, 1.0f, opacity)
            canvas.drawRoundRect(rect, corner, corner, fill)

            if (isActive) {
                haloPaint.color = applyColorWithAlpha(Theme.ACCENT, 0.40f, opacity)
                haloPaint.strokeWidth = 2f * density
                canvas.drawRoundRect(rect, corner, corner, haloPaint)
            }

            stroke.color = applyColorWithAlpha(if (isActive) Theme.ACCENT else 0x55FFFFFF, 1.0f, opacity)
            stroke.strokeWidth = if (isActive) 2.2f * density else 1.5f * density
            canvas.drawRoundRect(rect, corner, corner, stroke)
        }

        drawArm(northRect, upActive)
        drawArm(southRect, downActive)
        drawArm(westRect, leftActive)
        drawArm(eastRect, rightActive)

        // 2. Subtle diagonal bevel seams between adjacent arms
        stroke.color = applyColorWithAlpha(0x33000000, 1.0f, opacity)
        stroke.strokeWidth = 1.5f * density
        canvas.drawLine(x - arm, y - arm, x, y, stroke)
        canvas.drawLine(x + arm, y - arm, x, y, stroke)
        canvas.drawLine(x - arm, y + arm, x, y, stroke)
        canvas.drawLine(x + arm, y + arm, x, y, stroke)

        // 3. Center hub concave well
        val hubR = r * 0.28f
        fill.shader = RadialGradient(
            x, y, hubR,
            applyColorWithAlpha(0xFF14171E.toInt(), 1.0f, opacity),
            applyColorWithAlpha(0xFF282F3C.toInt(), 1.0f, opacity),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(x, y, hubR, fill)
        fill.shader = null

        stroke.color = applyColorWithAlpha(0x40FFFFFF, 1.0f, opacity)
        stroke.strokeWidth = 1.2f * density
        canvas.drawCircle(x, y, hubR, stroke)

        // 4. Directional arrow triangles engraved on each arm pointing outward
        val arrowDist = r * 0.65f
        val arrowSize = arm * 0.38f

        fun drawArrow(cx: Float, cy: Float, dirX: Float, dirY: Float, isActive: Boolean) {
            dpadArrowPath.reset()
            val tipX = cx + dirX * arrowSize
            val tipY = cy + dirY * arrowSize
            val perpX = -dirY * arrowSize * 0.75f
            val perpY = dirX * arrowSize * 0.75f
            val baseCenterX = cx - dirX * arrowSize * 0.5f
            val baseCenterY = cy - dirY * arrowSize * 0.5f

            dpadArrowPath.moveTo(tipX, tipY)
            dpadArrowPath.lineTo(baseCenterX + perpX, baseCenterY + perpY)
            dpadArrowPath.lineTo(baseCenterX - perpX, baseCenterY - perpY)
            dpadArrowPath.close()

            dpadArrowPaint.color = applyColorWithAlpha(
                if (isActive) Color.WHITE else 0x77FFFFFF.toInt(),
                1.0f,
                opacity
            )
            canvas.drawPath(dpadArrowPath, dpadArrowPaint)
        }

        drawArrow(x, y - arrowDist, 0f, -1f, upActive)
        drawArrow(x, y + arrowDist, 0f, 1f, downActive)
        drawArrow(x - arrowDist, y, -1f, 0f, leftActive)
        drawArrow(x + arrowDist, y, 1f, 0f, rightActive)
    }

    private fun drawGenericButton(
        canvas: Canvas,
        c: PadLayout.Control,
        x: Float,
        y: Float,
        r: Float,
        active: Boolean,
        opacity: Float
    ) {
        val isPill = c.id in listOf("select", "start", "home")
        val sink = if (active) 1.2f * density else 0f
        val drawY = y + sink

        if (isPill) {
            val halfW = r * 1.35f
            val halfH = r * 0.75f
            val corner = halfH * 0.55f
            val rect = RectF(x - halfW, drawY - halfH, x + halfW, drawY + halfH)

            if (active) {
                haloPaint.color = applyColorWithAlpha(Theme.ACCENT, 0.40f, opacity)
                haloPaint.strokeWidth = 2f * density
                val haloMargin = 2f * density
                canvas.drawRoundRect(
                    RectF(rect.left - haloMargin, rect.top - haloMargin, rect.right + haloMargin, rect.bottom + haloMargin),
                    corner + haloMargin, corner + haloMargin, haloPaint
                )
            }

            fill.color = applyColorWithAlpha(if (active) 0xFF4A5568.toInt() else 0xFF242A35.toInt(), 1.0f, opacity)
            canvas.drawRoundRect(rect, corner, corner, fill)

            stroke.color = applyColorWithAlpha(if (active) Theme.ACCENT else 0x88FFFFFF.toInt(), 1.0f, opacity)
            stroke.strokeWidth = 1.8f * density
            canvas.drawRoundRect(rect, corner, corner, stroke)

            text.color = applyColorWithAlpha(if (active) Color.WHITE else 0xDDFFFFFF.toInt(), 1.0f, opacity)
            val ts = min(unit() * 0.040f, halfH * 0.90f)
            text.textSize = ts
            canvas.drawText(c.label, x, drawY + ts * 0.35f, text)
        } else {
            val drawR = if (active) max(4f, r - 1.2f * density) else r
            if (active) {
                haloPaint.color = applyColorWithAlpha(Theme.ACCENT, 0.40f, opacity)
                haloPaint.strokeWidth = 2.5f * density
                canvas.drawCircle(x, y, r + 2.5f * density, haloPaint)
            }

            fill.color = applyColorWithAlpha(if (active) 0xCCFFFFFF.toInt() else 0x33282D37.toInt(), 1.0f, opacity)
            canvas.drawCircle(x, drawY, drawR, fill)

            stroke.color = applyColorWithAlpha(if (active) Theme.ACCENT else 0x80FFFFFF.toInt(), 1.0f, opacity)
            stroke.strokeWidth = 2f * density
            canvas.drawCircle(x, drawY, drawR, stroke)

            text.color = applyColorWithAlpha(if (active) Color.BLACK else Color.WHITE, 1.0f, opacity)
            val ts = min(unit() * 0.045f, drawR * 0.85f)
            text.textSize = ts
            canvas.drawText(c.label, x, drawY + ts * 0.35f, text)
        }
    }

    private fun drawMacroButton(
        canvas: Canvas,
        c: PadLayout.Control,
        x: Float,
        y: Float,
        r: Float,
        active: Boolean,
        opacity: Float
    ) {
        val isExecuting = isMacroPlaying && macroActiveControlId == c.id
        val isHighlighted = active || isExecuting
        val sink = if (isHighlighted) 1.5f * density else 0f
        val drawY = y + sink
        val drawR = if (isHighlighted) max(4f, r - 1.5f * density) else r

        // 1. Glowing halo exterior
        if (isHighlighted) {
            haloPaint.color = applyColorWithAlpha(Theme.ACCENT, 0.55f, opacity)
            haloPaint.strokeWidth = 3f * density
            canvas.drawCircle(x, y, r + 2.5f * density, haloPaint)
        }

        // 2. Brand-accent radial gradient fill
        val centerColor = if (isHighlighted) Theme.ACCENT else Theme.ACCENT_LO
        val edgeColor = if (isHighlighted) Theme.SURFACE_RAISED else Theme.SURFACE_SUNKEN
        fill.shader = RadialGradient(
            x, drawY, drawR,
            applyColorWithAlpha(centerColor, 0.95f, opacity),
            applyColorWithAlpha(edgeColor, 0.95f, opacity),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(x, drawY, drawR, fill)
        fill.shader = null

        // 3. Inner neon bevel
        innerBevelPaint.strokeWidth = 1.5f * density
        innerBevelPaint.color = applyColorWithAlpha(Theme.ACCENT, 0.50f, opacity)
        canvas.drawCircle(x, drawY, max(2f, drawR - 1.2f * density), innerBevelPaint)

        // 4. Outer rim stroke
        stroke.color = applyColorWithAlpha(if (isHighlighted) Color.WHITE else Theme.ACCENT, 1.0f, opacity)
        stroke.strokeWidth = 2.5f * density
        canvas.drawCircle(x, drawY, drawR, stroke)

        // 5. Center Lightning Icon
        val symbolPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (isHighlighted) Color.WHITE else Theme.ACCENT
            textSize = max(10f * density, drawR * 0.80f)
            typeface = Theme.TYPE_BOLD
            textAlign = Paint.Align.CENTER
        }
        val fm = symbolPaint.fontMetrics
        val iconY = drawY - (fm.ascent + fm.descent) / 2f
        canvas.drawText("⚡", x, iconY, symbolPaint)

        // 6. Name label beneath icon
        val macro = c.macroId?.let { MacroManager.getInstance(context).getMacro(it) }
        val labelText = macro?.name ?: c.label.ifEmpty { "MACRO" }
        val subLabelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = applyColorWithAlpha(0xEEFFFFFF.toInt(), 1.0f, opacity)
            textSize = max(7f * density, drawR * 0.28f)
            typeface = Theme.TYPE_BOLD
            textAlign = Paint.Align.CENTER
        }
        val displayLabel = if (labelText.length > 7) labelText.take(6) + "…" else labelText
        canvas.drawText(displayLabel, x, drawY + drawR * 0.58f, subLabelPaint)
    }

    private fun drawTouchpad(
        canvas: Canvas,
        c: PadLayout.Control,
        x: Float,
        y: Float,
        r: Float,
        active: Boolean,
        opacity: Float
    ) {
        val rect = RectF(x - r, y - r, x + r, y + r)
        val corner = r * 0.15f

        if (active) {
            haloPaint.color = applyColorWithAlpha(Theme.ACCENT, 0.35f, opacity)
            haloPaint.strokeWidth = 2f * density
            canvas.drawRoundRect(
                RectF(rect.left - 2f * density, rect.top - 2f * density, rect.right + 2f * density, rect.bottom + 2f * density),
                corner + 2f * density, corner + 2f * density, haloPaint
            )
        }

        fill.color = applyColorWithAlpha(0xFF1E232C.toInt(), if (active) 0.60f else 0.40f, opacity)
        canvas.drawRoundRect(rect, corner, corner, fill)

        stroke.color = applyColorWithAlpha(if (active) Theme.ACCENT else 0x55FFFFFF, 1.0f, opacity)
        stroke.strokeWidth = 1.8f * density
        canvas.drawRoundRect(rect, corner, corner, stroke)

        text.color = applyColorWithAlpha(Color.WHITE, 0.45f, opacity)
        canvas.drawText(c.label, x, y + text.textSize * 0.35f, text)
    }

    private fun drawEditHighlight(
        canvas: Canvas,
        c: PadLayout.Control,
        x: Float,
        y: Float,
        r: Float,
        u: Float
    ) {
        if (c == selectedControl) {
            selectPaint.color = Theme.ACCENT
            selectPaint.strokeWidth = 3f * density

            if (isTrigger(c)) {
                val halfW = r * 1.35f
                val halfH = r * 0.85f
                val corner = halfH * 0.42f
                val selRect = RectF(
                    x - halfW - 3f * density, y - halfH - 3f * density,
                    x + halfW + 3f * density, y + halfH + 3f * density
                )
                canvas.drawRoundRect(selRect, corner + 3f * density, corner + 3f * density, selectPaint)

                handlePaint.color = Theme.ACCENT
                val handleRadius = max(r * 0.20f, Theme.dp(context, 8).toFloat())
                val handleX = x + halfW
                canvas.drawCircle(handleX, y, handleRadius, handlePaint)
                stroke.color = Color.BLACK
                stroke.strokeWidth = 2f
                canvas.drawCircle(handleX, y, handleRadius, stroke)
            } else {
                canvas.drawCircle(x, y, r + 4f, selectPaint)

                handlePaint.color = Theme.ACCENT
                val handleRadius = max(r * 0.20f, Theme.dp(context, 8).toFloat())
                canvas.drawCircle(x + r, y, handleRadius, handlePaint)
                stroke.color = Color.BLACK
                stroke.strokeWidth = 2f
                canvas.drawCircle(x + r, y, handleRadius, stroke)
            }
        } else {
            selectPaint.color = Theme.ACCENT_WASH_HIGH
            selectPaint.strokeWidth = 1.5f
            if (isTrigger(c)) {
                val halfW = r * 1.35f
                val halfH = r * 0.85f
                val corner = halfH * 0.42f
                val bRect = RectF(x - halfW, y - halfH, x + halfW, y + halfH)
                canvas.drawRoundRect(bRect, corner, corner, selectPaint)
            } else {
                canvas.drawCircle(x, y, max(r, u * 0.03f), selectPaint)
            }
        }
    }
}
