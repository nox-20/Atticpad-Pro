package net.atticpad

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Where the on-screen controls live, and the editor's data model.
 *
 * Positions are stored NORMALISED (0..1 of the view's width/height) and radii
 * as a fraction of the shorter edge, so one saved layout survives a screen
 * rotation, a different phone, and split-screen.
 *
 * Each control supports:
 * - Position (cx, cy)
 * - Radius / size (r)
 * - Individual opacity (0.1..1.0)
 * - Radial action button separation adjustment
 */
class PadLayout private constructor(val controls: MutableList<Control>, var actionSpread: Float = 1.0f) {

    enum class Kind { STICK, DPAD, BUTTON, TOUCHPAD }

    enum class Orientation { LANDSCAPE, PORTRAIT }

    data class Control(
        val id: String,
        val kind: Kind,
        val bit: Int,
        val label: String,
        val stick: Int,
        var cx: Float,
        var cy: Float,
        var r: Float,
        var opacity: Float = 1.0f,
        var macroId: String? = null,
    )

    fun copy(): PadLayout = PadLayout(controls.map { it.copy() }.toMutableList(), actionSpread)

    fun getControl(id: String): Control? = controls.firstOrNull { it.id == id }

    fun adjustActionButtonsSpread(factor: Float) {
        val actionButtons = controls.filter { it.id in listOf("a", "b", "x", "y") }
        if (actionButtons.isEmpty()) return
        val avgX = actionButtons.map { it.cx }.average().toFloat()
        val avgY = actionButtons.map { it.cy }.average().toFloat()
        for (btn in actionButtons) {
            val dx = btn.cx - avgX
            val dy = btn.cy - avgY
            btn.cx = (avgX + dx * factor).coerceIn(0.04f, 0.96f)
            btn.cy = (avgY + dy * factor).coerceIn(0.04f, 0.96f)
        }
        actionSpread = (actionSpread * factor).coerceIn(0.5f, 2.5f)
    }

    fun nudgeControl(id: String, dxNorm: Float, dyNorm: Float) {
        val c = getControl(id) ?: return
        c.cx = (c.cx + dxNorm).coerceIn(0.03f, 0.97f)
        c.cy = (c.cy + dyNorm).coerceIn(0.03f, 0.97f)
    }

    fun toJson(): String {
        val root = JSONObject()
        root.put("actionSpread", actionSpread.toDouble())
        val arr = JSONArray()
        for (c in controls) {
            val obj = JSONObject()
                .put("id", c.id)
                .put("kind", c.kind.name)
                .put("bit", c.bit)
                .put("label", c.label)
                .put("stick", c.stick)
                .put("cx", c.cx.toDouble())
                .put("cy", c.cy.toDouble())
                .put("r", c.r.toDouble())
                .put("opacity", c.opacity.toDouble())
            if (!c.macroId.isNullOrEmpty()) {
                obj.put("macroId", c.macroId)
            }
            arr.put(obj)
        }
        root.put("controls", arr)
        return root.toString()
    }

    companion object {
        private const val PREFS = "atticpad"
        private const val KEY_LAYOUT_LANDSCAPE = "pad_layout_v1"
        private const val KEY_LAYOUT_PORTRAIT = "pad_layout_portrait_v1"

        private fun keyFor(orientation: Orientation): String = when (orientation) {
            Orientation.LANDSCAPE -> KEY_LAYOUT_LANDSCAPE
            Orientation.PORTRAIT -> KEY_LAYOUT_PORTRAIT
        }

        private fun prefs(context: Context) =
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

        fun default(orientation: Orientation): PadLayout = when (orientation) {
            Orientation.LANDSCAPE -> defaultLandscape()
            Orientation.PORTRAIT -> defaultPortrait()
        }

        /**
         * Default landscape layout.
         * Includes dual sticks, D-pad, 4 action buttons, triggers ZL/ZR, shoulder L/R,
         * Select/Start/Home, L3/R3, and touchpad.
         */
        fun defaultLandscape(): PadLayout {
            val c = mutableListOf(
                Control("stick_l", Kind.STICK, 0, "L", 0, 0.15f, 0.68f, 0.155f, 1.0f),
                Control("stick_r", Kind.STICK, 0, "R", 1, 0.85f, 0.68f, 0.155f, 1.0f),
                Control("dpad", Kind.DPAD, 0, "", 0, 0.14f, 0.30f, 0.135f, 1.0f),

                Control("a", Kind.BUTTON, AtticPadNative.BTN_A, "A", 0, 0.925f, 0.30f, 0.062f, 1.0f),
                Control("b", Kind.BUTTON, AtticPadNative.BTN_B, "B", 0, 0.855f, 0.40f, 0.062f, 1.0f),
                Control("x", Kind.BUTTON, AtticPadNative.BTN_X, "X", 0, 0.855f, 0.20f, 0.062f, 1.0f),
                Control("y", Kind.BUTTON, AtticPadNative.BTN_Y, "Y", 0, 0.785f, 0.30f, 0.062f, 1.0f),

                Control("l", Kind.BUTTON, AtticPadNative.BTN_L, "L", 0, 0.09f, 0.075f, 0.058f, 1.0f),
                Control("zl", Kind.BUTTON, AtticPadNative.BTN_ZL, "ZL", 0, 0.21f, 0.075f, 0.058f, 1.0f),
                Control("r", Kind.BUTTON, AtticPadNative.BTN_R, "R", 0, 0.91f, 0.075f, 0.058f, 1.0f),
                Control("zr", Kind.BUTTON, AtticPadNative.BTN_ZR, "ZR", 0, 0.79f, 0.075f, 0.058f, 1.0f),

                Control("select", Kind.BUTTON, AtticPadNative.BTN_SELECT, "SEL", 0, 0.40f, 0.19f, 0.048f, 1.0f),
                Control("home", Kind.BUTTON, AtticPadNative.BTN_HOME, "HOME", 0, 0.50f, 0.19f, 0.045f, 1.0f),
                Control("start", Kind.BUTTON, AtticPadNative.BTN_START, "START", 0, 0.60f, 0.19f, 0.048f, 1.0f),
                Control("l3", Kind.BUTTON, AtticPadNative.BTN_L3, "L3", 0, 0.33f, 0.86f, 0.048f, 1.0f),
                Control("r3", Kind.BUTTON, AtticPadNative.BTN_R3, "R3", 0, 0.67f, 0.86f, 0.048f, 1.0f),

                Control("touchpad", Kind.TOUCHPAD, 0, "touch", 0, 0.50f, 0.42f, 0.155f, 0.9f),
            )
            return PadLayout(c, 1.0f)
        }

        fun defaultPortrait(): PadLayout {
            val c = mutableListOf(
                Control("stick_l", Kind.STICK, 0, "L", 0, 0.24f, 0.83f, 0.145f, 1.0f),
                Control("stick_r", Kind.STICK, 0, "R", 1, 0.76f, 0.83f, 0.145f, 1.0f),
                Control("dpad", Kind.DPAD, 0, "", 0, 0.18f, 0.585f, 0.115f, 1.0f),

                Control("a", Kind.BUTTON, AtticPadNative.BTN_A, "A", 0, 0.885f, 0.585f, 0.06f, 1.0f),
                Control("b", Kind.BUTTON, AtticPadNative.BTN_B, "B", 0, 0.82f, 0.655f, 0.06f, 1.0f),
                Control("x", Kind.BUTTON, AtticPadNative.BTN_X, "X", 0, 0.82f, 0.515f, 0.06f, 1.0f),
                Control("y", Kind.BUTTON, AtticPadNative.BTN_Y, "Y", 0, 0.755f, 0.585f, 0.06f, 1.0f),

                Control("l", Kind.BUTTON, AtticPadNative.BTN_L, "L", 0, 0.12f, 0.095f, 0.058f, 1.0f),
                Control("zl", Kind.BUTTON, AtticPadNative.BTN_ZL, "ZL", 0, 0.30f, 0.095f, 0.058f, 1.0f),
                Control("r", Kind.BUTTON, AtticPadNative.BTN_R, "R", 0, 0.88f, 0.095f, 0.058f, 1.0f),
                Control("zr", Kind.BUTTON, AtticPadNative.BTN_ZR, "ZR", 0, 0.70f, 0.095f, 0.058f, 1.0f),

                Control("select", Kind.BUTTON, AtticPadNative.BTN_SELECT, "SEL", 0, 0.36f, 0.205f, 0.045f, 1.0f),
                Control("home", Kind.BUTTON, AtticPadNative.BTN_HOME, "HOME", 0, 0.50f, 0.205f, 0.042f, 1.0f),
                Control("start", Kind.BUTTON, AtticPadNative.BTN_START, "START", 0, 0.64f, 0.205f, 0.045f, 1.0f),

                Control("l3", Kind.BUTTON, AtticPadNative.BTN_L3, "L3", 0, 0.40f, 0.905f, 0.042f, 1.0f),
                Control("r3", Kind.BUTTON, AtticPadNative.BTN_R3, "R3", 0, 0.60f, 0.905f, 0.042f, 1.0f),

                Control("touchpad", Kind.TOUCHPAD, 0, "touch", 0, 0.50f, 0.36f, 0.10f, 0.9f),
            )
            return PadLayout(c, 1.0f)
        }

        fun fromJson(jsonStr: String, orientation: Orientation): PadLayout {
            val defLayout = default(orientation)
            try {
                val byId = defLayout.controls.associateBy { it.id }
                val trimmed = jsonStr.trim()
                if (trimmed.startsWith("{")) {
                    val root = JSONObject(trimmed)
                    val spread = root.optDouble("actionSpread", 1.0).toFloat()
                    val arr = root.optJSONArray("controls") ?: JSONArray()
                    val loaded = parseControls(arr, byId)
                    if (loaded.isNotEmpty()) return PadLayout(loaded, spread)
                } else if (trimmed.startsWith("[")) {
                    val arr = JSONArray(trimmed)
                    val loaded = parseControls(arr, byId)
                    if (loaded.isNotEmpty()) return PadLayout(loaded, 1.0f)
                }
            } catch (_: Exception) {
                return default(orientation)
            }
            return default(orientation)
        }

        private fun parseControls(arr: JSONArray, byId: Map<String, Control>): MutableList<Control> {
            val result = mutableListOf<Control>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val id = o.optString("id")
                val template = byId[id]
                val c = if (template != null) {
                    template.copy()
                } else if (id.startsWith("macro_") || o.has("macroId")) {
                    val kindStr = o.optString("kind", Kind.BUTTON.name)
                    val kind = try { Kind.valueOf(kindStr) } catch (_: Exception) { Kind.BUTTON }
                    Control(
                        id = id,
                        kind = kind,
                        bit = o.optInt("bit", 0),
                        label = o.optString("label", "⚡"),
                        stick = o.optInt("stick", 0),
                        cx = 0.5f,
                        cy = 0.5f,
                        r = 0.055f,
                        opacity = 1.0f,
                        macroId = o.optString("macroId").ifEmpty { null }
                    )
                } else {
                    continue
                }
                c.cx = o.optDouble("cx", c.cx.toDouble()).toFloat().coerceIn(0f, 1f)
                c.cy = o.optDouble("cy", c.cy.toDouble()).toFloat().coerceIn(0f, 1f)
                c.r = o.optDouble("r", c.r.toDouble()).toFloat().coerceIn(0.02f, 0.35f)
                c.opacity = o.optDouble("opacity", c.opacity.toDouble()).toFloat().coerceIn(0.1f, 1.0f)
                if (o.has("macroId")) {
                    c.macroId = o.optString("macroId").ifEmpty { null }
                }
                result.add(c)
            }
            return result
        }

        fun load(context: Context, orientation: Orientation): PadLayout {
            val json = prefs(context).getString(keyFor(orientation), null) ?: return default(orientation)
            return fromJson(json, orientation)
        }

        fun save(context: Context, layout: PadLayout, orientation: Orientation) {
            prefs(context).edit()
                .putString(keyFor(orientation), layout.toJson())
                .apply()
        }

        fun reset(context: Context, orientation: Orientation) {
            prefs(context).edit().remove(keyFor(orientation)).apply()
        }
    }
}
