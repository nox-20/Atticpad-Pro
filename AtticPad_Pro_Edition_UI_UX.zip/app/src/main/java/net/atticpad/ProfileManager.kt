package net.atticpad

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Manages user gamepad profiles with persistent storage.
 *
 * Requirements:
 * - Create custom named profiles
 * - Each profile saves: positions, sizes, opacities, action button separation, and visual style per orientation
 * - Actions: Select, Rename, Duplicate, Delete, Create from current, Restore default
 * - Restores last used profile on app open
 * - Preloaded genres: Predeterminado, Lucha (Fighting), Carreras (Racing), Acción (Action)
 */
class ProfileManager private constructor(private val context: Context) {

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val profiles = mutableListOf<PadProfile>()
    private var activeProfileId: String = DEFAULT_ID

    init {
        loadProfiles()
    }

    @Synchronized
    fun listProfiles(): List<PadProfile> = profiles.toList()

    @Synchronized
    fun getActiveProfile(): PadProfile {
        return profiles.firstOrNull { it.id == activeProfileId }
            ?: profiles.firstOrNull()
            ?: createDefaultProfile().also {
                profiles.add(it)
                activeProfileId = it.id
                saveAll()
            }
    }

    @Synchronized
    fun setActiveProfile(id: String): PadProfile {
        val found = profiles.firstOrNull { it.id == id } ?: getActiveProfile()
        activeProfileId = found.id
        prefs.edit().putString(KEY_ACTIVE_ID, activeProfileId).apply()
        return found
    }

    @Synchronized
    fun createProfile(name: String, baseProfile: PadProfile? = null): PadProfile {
        val id = "profile_${System.currentTimeMillis()}"
        val cleanName = name.trim().ifEmpty { "Perfil ${profiles.size + 1}" }
        val newProfile = if (baseProfile != null) {
            baseProfile.copy(newId = id, newName = cleanName)
        } else {
            val active = getActiveProfile()
            active.copy(newId = id, newName = cleanName)
        }
        profiles.add(newProfile)
        activeProfileId = id
        saveAll()
        return newProfile
    }

    @Synchronized
    fun duplicateProfile(id: String): PadProfile {
        val target = profiles.firstOrNull { it.id == id } ?: getActiveProfile()
        val newId = "profile_${System.currentTimeMillis()}"
        val newName = "${target.name} (Copia)"
        val dup = target.copy(newId = newId, newName = newName)
        profiles.add(dup)
        activeProfileId = newId
        saveAll()
        return dup
    }

    @Synchronized
    fun renameProfile(id: String, newName: String): Boolean {
        val clean = newName.trim()
        if (clean.isEmpty()) return false
        val p = profiles.firstOrNull { it.id == id } ?: return false
        p.name = clean
        saveAll()
        return true
    }

    @Synchronized
    fun deleteProfile(id: String): Boolean {
        if (profiles.size <= 1) return false // Cannot delete only profile
        val index = profiles.indexOfFirst { it.id == id }
        if (index < 0) return false
        profiles.removeAt(index)
        if (activeProfileId == id) {
            activeProfileId = profiles.first().id
        }
        saveAll()
        return true
    }

    @Synchronized
    fun resetActiveProfileToDefault(orientation: PadLayout.Orientation) {
        val p = getActiveProfile()
        when (orientation) {
            PadLayout.Orientation.LANDSCAPE -> {
                val def = PadLayout.defaultLandscape()
                p.landscapeLayout.controls.clear()
                p.landscapeLayout.controls.addAll(def.controls)
                p.landscapeLayout.actionSpread = def.actionSpread
            }
            PadLayout.Orientation.PORTRAIT -> {
                val def = PadLayout.defaultPortrait()
                p.portraitLayout.controls.clear()
                p.portraitLayout.controls.addAll(def.controls)
                p.portraitLayout.actionSpread = def.actionSpread
            }
        }
        saveAll()
    }

    @Synchronized
    fun updateActiveLayout(orientation: PadLayout.Orientation, layout: PadLayout) {
        val p = getActiveProfile()
        when (orientation) {
            PadLayout.Orientation.LANDSCAPE -> {
                p.landscapeLayout.controls.clear()
                p.landscapeLayout.controls.addAll(layout.controls.map { it.copy() })
                p.landscapeLayout.actionSpread = layout.actionSpread
            }
            PadLayout.Orientation.PORTRAIT -> {
                p.portraitLayout.controls.clear()
                p.portraitLayout.controls.addAll(layout.controls.map { it.copy() })
                p.portraitLayout.actionSpread = layout.actionSpread
            }
        }
        saveAll()
    }

    @Synchronized
    fun updateActiveStyle(style: ButtonStyle) {
        val p = getActiveProfile()
        p.style = style
        saveAll()
    }

    @Synchronized
    fun saveActiveProfile() {
        saveAll()
    }

    private fun saveAll() {
        prefs.edit()
            .putString(KEY_ACTIVE_ID, activeProfileId)
            .putString(KEY_PROFILES_JSON, serializeProfiles())
            .apply()
    }

    private fun serializeProfiles(): String {
        val arr = JSONArray()
        for (p in profiles) {
            arr.put(p.toJson())
        }
        return arr.toString()
    }

    private fun loadProfiles() {
        profiles.clear()
        val jsonStr = prefs.getString(KEY_PROFILES_JSON, null)
        if (!jsonStr.isNullOrEmpty()) {
            try {
                val arr = JSONArray(jsonStr)
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    profiles.add(PadProfile.fromJson(obj))
                }
            } catch (_: Exception) {
                profiles.clear()
            }
        }

        if (profiles.isEmpty()) {
            profiles.addAll(buildDefaultPresets())
        }

        val savedActiveId = prefs.getString(KEY_ACTIVE_ID, null)
        activeProfileId = if (savedActiveId != null && profiles.any { it.id == savedActiveId }) {
            savedActiveId
        } else {
            profiles.first().id
        }
    }

    private fun buildDefaultPresets(): List<PadProfile> {
        val list = mutableListOf<PadProfile>()

        // 1. Predeterminado (Standard balanced)
        list.add(createDefaultProfile())

        // 2. Lucha / Fighting (Tighter action button grouping, larger buttons & D-pad)
        val fightLand = PadLayout.defaultLandscape()
        fightLand.controls.filter { it.id in listOf("a", "b", "x", "y") }.forEach {
            it.r = 0.072f
        }
        fightLand.getControl("dpad")?.let { it.r = 0.155f }
        fightLand.adjustActionButtonsSpread(0.85f)
        val fightPort = PadLayout.defaultPortrait()
        fightPort.controls.filter { it.id in listOf("a", "b", "x", "y") }.forEach {
            it.r = 0.070f
        }
        fightPort.getControl("dpad")?.let { it.r = 0.135f }
        fightPort.adjustActionButtonsSpread(0.85f)
        list.add(PadProfile("preset_fighting", "Lucha / Fighting", ButtonStyle.NINTENDO, fightLand, fightPort))

        // 3. Carreras / Racing (Prominent triggers ZL/ZR, prominent left stick)
        val raceLand = PadLayout.defaultLandscape()
        raceLand.getControl("zl")?.let { it.r = 0.075f; it.cx = 0.22f }
        raceLand.getControl("zr")?.let { it.r = 0.075f; it.cx = 0.78f }
        raceLand.getControl("stick_l")?.let { it.r = 0.170f }
        raceLand.getControl("a")?.let { it.r = 0.070f }
        raceLand.getControl("b")?.let { it.r = 0.070f }
        val racePort = PadLayout.defaultPortrait()
        racePort.getControl("zl")?.let { it.r = 0.070f }
        racePort.getControl("zr")?.let { it.r = 0.070f }
        list.add(PadProfile("preset_racing", "Carreras / Racing", ButtonStyle.XBOX, raceLand, racePort))

        // 4. Acción / Action (Balanced twin sticks, accessible shoulder buttons)
        val actionLand = PadLayout.defaultLandscape()
        actionLand.getControl("stick_l")?.let { it.r = 0.160f }
        actionLand.getControl("stick_r")?.let { it.r = 0.160f }
        actionLand.getControl("l")?.let { it.r = 0.065f }
        actionLand.getControl("r")?.let { it.r = 0.065f }
        val actionPort = PadLayout.defaultPortrait()
        list.add(PadProfile("preset_action", "Acción / Shooters", ButtonStyle.PLAYSTATION, actionLand, actionPort))

        return list
    }

    private fun createDefaultProfile(): PadProfile {
        return PadProfile(
            id = DEFAULT_ID,
            name = "Predeterminado",
            style = ButtonStyle.NINTENDO,
            landscapeLayout = PadLayout.defaultLandscape(),
            portraitLayout = PadLayout.defaultPortrait()
        )
    }

    companion object {
        private const val PREFS_NAME = "atticpad_profiles_v1"
        private const val KEY_PROFILES_JSON = "profiles_list"
        private const val KEY_ACTIVE_ID = "active_profile_id"
        private const val DEFAULT_ID = "profile_default"

        @Volatile
        private var instance: ProfileManager? = null

        fun getInstance(context: Context): ProfileManager =
            instance ?: synchronized(this) {
                instance ?: ProfileManager(context.applicationContext).also { instance = it }
            }
    }
}
