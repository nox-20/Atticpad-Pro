package net.atticpad

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

enum class MacroEventType { BUTTON, TRIGGER }

fun getBitForControlId(controlId: String): Int = when (controlId.lowercase()) {
    "a" -> AtticPadNative.BTN_A
    "b" -> AtticPadNative.BTN_B
    "x" -> AtticPadNative.BTN_X
    "y" -> AtticPadNative.BTN_Y
    "l", "lb" -> AtticPadNative.BTN_L
    "r", "rb" -> AtticPadNative.BTN_R
    "zl", "lt" -> AtticPadNative.BTN_ZL
    "zr", "rt" -> AtticPadNative.BTN_ZR
    "select", "view", "back" -> AtticPadNative.BTN_SELECT
    "start", "menu" -> AtticPadNative.BTN_START
    "home", "xbox", "guide" -> AtticPadNative.BTN_HOME
    "l3" -> AtticPadNative.BTN_L3
    "r3" -> AtticPadNative.BTN_R3
    "dpad_up" -> AtticPadNative.BTN_DPAD_UP
    "dpad_down" -> AtticPadNative.BTN_DPAD_DOWN
    "dpad_left" -> AtticPadNative.BTN_DPAD_LEFT
    "dpad_right" -> AtticPadNative.BTN_DPAD_RIGHT
    else -> 0
}

fun isTriggerControl(controlId: String): Boolean =
    controlId.lowercase() in listOf("zl", "zr", "lt", "rt")

data class MacroEvent(
    val controlId: String,
    var pressed: Boolean,
    var delayMs: Long,
    var type: MacroEventType = if (isTriggerControl(controlId)) MacroEventType.TRIGGER else MacroEventType.BUTTON,
    var bit: Int = getBitForControlId(controlId),
    var value: Int = if (isTriggerControl(controlId)) (if (pressed) 32767 else 0) else 0
) {
    fun toJson(): JSONObject = JSONObject()
        .put("controlId", controlId)
        .put("pressed", pressed)
        .put("delayMs", delayMs)
        .put("type", type.name)
        .put("bit", bit)
        .put("value", value)

    companion object {
        fun fromJson(json: JSONObject): MacroEvent {
            val controlId = json.optString("controlId", "")
            val defaultType = if (isTriggerControl(controlId)) MacroEventType.TRIGGER else MacroEventType.BUTTON
            val typeStr = json.optString("type", defaultType.name)
            val type = try {
                MacroEventType.valueOf(typeStr)
            } catch (_: Exception) {
                defaultType
            }
            val pressed = json.optBoolean("pressed", false)
            val parsedBit = json.optInt("bit", 0)
            val bit = if (parsedBit != 0) parsedBit else getBitForControlId(controlId)
            val parsedValue = json.optInt("value", -1)
            val value = if (parsedValue >= 0) parsedValue else {
                if (type == MacroEventType.TRIGGER) (if (pressed) 32767 else 0) else 0
            }
            return MacroEvent(
                controlId = controlId,
                pressed = pressed,
                delayMs = json.optLong("delayMs", 0L),
                type = type,
                bit = bit,
                value = value
            )
        }
    }
}

data class Macro(
    val id: String,
    var name: String,
    val events: MutableList<MacroEvent>
) {
    fun deepCopy(newId: String = id, newName: String = name): Macro =
        Macro(newId, newName, events.map { it.copy() }.toMutableList())

    fun toJson(): JSONObject {
        val arr = JSONArray()
        events.forEach { arr.put(it.toJson()) }
        return JSONObject()
            .put("id", id)
            .put("name", name)
            .put("events", arr)
    }

    companion object {
        fun fromJson(json: JSONObject): Macro {
            val id = json.optString("id", "").ifEmpty { "macro_${System.currentTimeMillis()}_${(100..999).random()}" }
            val name = json.optString("name", "Macro")
            val arr = json.optJSONArray("events")
            val list = mutableListOf<MacroEvent>()
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    arr.optJSONObject(i)?.let { list.add(MacroEvent.fromJson(it)) }
                }
            }
            return Macro(id, name, list)
        }
    }
}

/**
 * Global persistent manager for AtticPad macros.
 * Stores macros independently of profiles in SharedPreferences ("atticpad_macros_v1").
 */
class MacroManager private constructor(context: Context) {
    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val macrosMap = LinkedHashMap<String, Macro>()

    init {
        loadMacros()
    }

    @Synchronized
    private fun loadMacros() {
        macrosMap.clear()
        val jsonStr = prefs.getString(KEY_MACROS, null)
        if (!jsonStr.isNullOrEmpty()) {
            try {
                val arr = JSONArray(jsonStr)
                for (i in 0 until arr.length()) {
                    val obj = arr.optJSONObject(i) ?: continue
                    val macro = Macro.fromJson(obj)
                    macrosMap[macro.id] = macro
                }
            } catch (_: Exception) {}
        }
    }

    @Synchronized
    fun saveMacros() {
        val arr = JSONArray()
        for (m in macrosMap.values) {
            arr.put(m.toJson())
        }
        prefs.edit().putString(KEY_MACROS, arr.toString()).apply()
    }

    @Synchronized
    fun listMacros(): List<Macro> = macrosMap.values.map { it.deepCopy() }

    @Synchronized
    fun getMacro(id: String): Macro? = macrosMap[id]?.deepCopy()

    @Synchronized
    fun saveMacro(macro: Macro) {
        macrosMap[macro.id] = macro.deepCopy()
        saveMacros()
    }

    @Synchronized
    fun deleteMacro(id: String): Boolean {
        val removed = macrosMap.remove(id) != null
        if (removed) {
            saveMacros()
        }
        return removed
    }

    @Synchronized
    fun renameMacro(id: String, newName: String): Boolean {
        val m = macrosMap[id] ?: return false
        m.name = newName
        saveMacros()
        return true
    }

    companion object {
        private const val PREFS_NAME = "atticpad_macros_v1"
        private const val KEY_MACROS = "saved_macros_list"

        @Volatile
        private var instance: MacroManager? = null

        fun getInstance(context: Context): MacroManager =
            instance ?: synchronized(this) {
                instance ?: MacroManager(context).also { instance = it }
            }
    }
}
