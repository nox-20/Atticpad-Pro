package net.atticpad

import android.app.AlertDialog
import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

/**
 * Floating toolbar for PadView Edit Mode.
 *
 * Provides:
 * - Selected control status & properties
 * - Cardinal arrow nudge buttons (▲ ▼ ◄ ►) for fine positioning
 * - Opacity adjustment slider (10% - 100%)
 * - Radius / size – and + buttons
 * - Radial separation – and + buttons for the 4 action buttons
 * - "Restaurar" button: reverts current orientation to default layout
 * - "Guardar" button: saves profile and returns to play mode
 */
class EditOverlayView(
    context: Context,
    private val padView: PadView,
    private val getCurrentOrientation: () -> PadLayout.Orientation,
    private val onSaveAndExit: () -> Unit,
    private val onResetDefault: () -> Unit
) : FrameLayout(context) {

    private val container: LinearLayout
    private val recordingBanner: LinearLayout
    private val recordingBannerText: TextView
    private val snapGridBtn: Button
    private val infoText: TextView
    private val opacityLabel: TextView
    private val opacityBar: SeekBar
    private val sizeLabel: TextView
    private val spreadLabel: TextView
    private val deleteBtn: Button

    init {
        // Top non-modal banner for immersive macro recording
        recordingBanner = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
            val bg = GradientDrawable().apply {
                setColor(0xF01A090D.toInt())
                cornerRadius = Theme.dp(context, 20).toFloat()
                setStroke(Theme.dp(context, 2), 0xFFFF1744.toInt())
            }
            background = bg
            val hp = Theme.dp(context, Theme.SPACE_MD); val vp = Theme.dp(context, 8)
            setPadding(hp, vp, hp, vp)
            isClickable = true
            isFocusable = true
            setOnClickListener {
                stopMacroRecordingFlow()
            }
        }

        recordingBannerText = TextView(context).apply {
            text = "🔴 GRABANDO... Toca aquí para detener"
            textSize = 12f
            setTextColor(Theme.ERROR)
            typeface = Theme.TYPE_BOLD
        }
        recordingBanner.addView(recordingBannerText)

        addView(
            recordingBanner,
            LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                topMargin = Theme.dp(context, 16)
            }
        )

        // Dark translucent panel matching app theme
        val panelBg = GradientDrawable().apply {
            setColor(0xF21C212B.toInt()) // Theme dark slate (95% opacity)
            cornerRadius = Theme.dp(context, Theme.RADIUS_LG).toFloat()
            setStroke(Theme.dp(context, 1), 0x33FFFFFF)
        }

        container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            background = panelBg
            val p = Theme.dp(context, Theme.SPACE_SM)
            setPadding(p, p, p, p)
            isClickable = true
            isFocusable = true
        }

        // --- ROW 1: Title & Selected control info ---
        val headerRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val titleBadge = TextView(context).apply {
            text = "MODO EDICIÓN"
            textSize = 11f
            setTextColor(Theme.ACCENT)
            background = GradientDrawable().apply {
                setColor(Theme.ACCENT_WASH_HIGH)
                cornerRadius = Theme.dp(context, 4).toFloat()
                setStroke(Theme.dp(context, 1), Theme.ACCENT_WASH_HIGH)
            }
            val hp = Theme.dp(context, 6); val vp = Theme.dp(context, 2)
            setPadding(hp, vp, hp, vp)
        }
        headerRow.addView(titleBadge)

        infoText = TextView(context).apply {
            text = "Toca un control para editar"
            textSize = 12f
            setTextColor(Theme.TEXT_PRIMARY)
            setPadding(Theme.dp(context, Theme.SPACE_SM), 0, Theme.dp(context, Theme.SPACE_SM), 0)
        }
        headerRow.addView(infoText, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        val bodyContainer = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }

        var isBodyVisible = false
        val toggleExpandBtn = Button(context).apply {
            text = "▸ Herramientas"
            textSize = 11f
            setTextColor(Theme.TEXT_PRIMARY)
            background = Theme.secondaryButtonBackground(context)
            val hp = Theme.dp(context, Theme.SPACE_SM); val vp = Theme.dp(context, 2)
            setPadding(hp, vp, hp, vp)
            minimumHeight = Theme.dp(context, 32)
            setOnClickListener {
                isBodyVisible = !isBodyVisible
                bodyContainer.visibility = if (isBodyVisible) View.VISIBLE else View.GONE
                text = if (isBodyVisible) "▾ Herramientas" else "▸ Herramientas"
            }
        }
        headerRow.addView(toggleExpandBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            marginEnd = Theme.dp(context, Theme.SPACE_XS)
        })

        val doneHeaderBtn = Button(context).apply {
            text = "Listo ✓"
            textSize = 12f
            setTextColor(Theme.TEXT_PRIMARY)
            background = GradientDrawable().apply {
                setColor(Theme.SURFACE)
                cornerRadius = Theme.dp(context, Theme.RADIUS_SM).toFloat()
                setStroke(Theme.dp(context, 1), Theme.ACCENT)
            }
            val hp = Theme.dp(context, Theme.SPACE_MD); val vp = Theme.dp(context, 2)
            setPadding(hp, vp, hp, vp)
            minimumHeight = Theme.dp(context, 32)
            setOnClickListener {
                padView.setEditMode(false)
                onSaveAndExit()
            }
        }
        headerRow.addView(doneHeaderBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        container.addView(headerRow)
        container.addView(bodyContainer)

        // --- ROW 2: Fine positioning cardinal arrows + Size + Spread ---
        val scrollContent = HorizontalScrollView(context).apply {
            isHorizontalScrollBarEnabled = false
        }
        val controlsRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, Theme.dp(context, Theme.SPACE_XS), 0, Theme.dp(context, Theme.SPACE_XS))
        }

        // Cardinal Nudge Pad
        val nudgeLabel = TextView(context).apply {
            text = "Posición fina:"
            textSize = 11f
            setTextColor(Theme.TEXT_SECONDARY)
            setPadding(0, 0, Theme.dp(context, 4), 0)
        }
        controlsRow.addView(nudgeLabel)

        fun arrowBtn(label: String, dx: Float, dy: Float): Button {
            return Button(context).apply {
                text = label
                textSize = 14f
                setTextColor(Theme.TEXT_PRIMARY)
                background = Theme.secondaryButtonBackground(context)
                val sz = Theme.dp(context, 34)
                layoutParams = LinearLayout.LayoutParams(sz, sz).apply {
                    marginEnd = Theme.dp(context, 2)
                }
                setOnClickListener { padView.nudgeSelected(dx, dy) }
            }
        }
        controlsRow.addView(arrowBtn("◄", -0.006f, 0f))
        controlsRow.addView(arrowBtn("▲", 0f, -0.006f))
        controlsRow.addView(arrowBtn("▼", 0f, 0.006f))
        controlsRow.addView(arrowBtn("►", 0.006f, 0f))

        // Separator
        controlsRow.addView(createVerticalDivider(context))

        // Size adjustment
        sizeLabel = TextView(context).apply {
            text = "Tamaño:"
            textSize = 11f
            setTextColor(Theme.TEXT_SECONDARY)
            setPadding(Theme.dp(context, 4), 0, Theme.dp(context, 4), 0)
        }
        controlsRow.addView(sizeLabel)

        fun sizeBtn(label: String, delta: Float): Button {
            return Button(context).apply {
                text = label
                textSize = 16f
                setTextColor(Theme.TEXT_PRIMARY)
                background = Theme.secondaryButtonBackground(context)
                val sz = Theme.dp(context, 34)
                layoutParams = LinearLayout.LayoutParams(sz, sz).apply {
                    marginEnd = Theme.dp(context, 3)
                }
                setOnClickListener {
                    val sel = padView.selectedControl
                    if (sel != null) {
                        padView.setSelectedRadius(sel.r + delta)
                        updateControlInfo(sel)
                    }
                }
            }
        }
        controlsRow.addView(sizeBtn("–", -0.010f))
        controlsRow.addView(sizeBtn("+", 0.010f))

        // Separator
        controlsRow.addView(createVerticalDivider(context))

        // Action Buttons Spread
        spreadLabel = TextView(context).apply {
            text = "Separación ABXY:"
            textSize = 11f
            setTextColor(Theme.TEXT_SECONDARY)
            setPadding(Theme.dp(context, 4), 0, Theme.dp(context, 4), 0)
        }
        controlsRow.addView(spreadLabel)

        fun spreadBtn(label: String, factor: Float): Button {
            return Button(context).apply {
                text = label
                textSize = 16f
                setTextColor(Theme.TEXT_PRIMARY)
                background = Theme.secondaryButtonBackground(context)
                val sz = Theme.dp(context, 34)
                layoutParams = LinearLayout.LayoutParams(sz, sz).apply {
                    marginEnd = Theme.dp(context, 3)
                }
                setOnClickListener {
                    padView.adjustActionSpread(factor)
                }
            }
        }
        controlsRow.addView(spreadBtn("–", 0.90f))
        controlsRow.addView(spreadBtn("+", 1.10f))

        // Separator
        controlsRow.addView(createVerticalDivider(context))

        // Snap to Grid Toggle Button
        snapGridBtn = Button(context).apply {
            textSize = 11f
            val hp = Theme.dp(context, Theme.SPACE_SM); val vp = Theme.dp(context, 2)
            setPadding(hp, vp, hp, vp)
            minimumHeight = Theme.dp(context, 34)
            setOnClickListener {
                padView.snapToGrid = !padView.snapToGrid
                Haptics.feedback(this, HapticFeedbackConstants.VIRTUAL_KEY)
                updateSnapGridStyle()
                padView.invalidate()
            }
        }
        updateSnapGridStyle()
        controlsRow.addView(snapGridBtn)

        scrollContent.addView(controlsRow)
        bodyContainer.addView(scrollContent)

        // --- ROW 3: Opacity slider ---
        val opacityRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, Theme.dp(context, 2), 0, Theme.dp(context, Theme.SPACE_XS))
        }

        opacityLabel = TextView(context).apply {
            text = "Opacidad: 100%"
            textSize = 11f
            setTextColor(Theme.TEXT_SECONDARY)
            minWidth = Theme.dp(context, 95)
        }
        opacityRow.addView(opacityLabel)

        opacityBar = SeekBar(context).apply {
            max = 90 // 10% to 100%
            progress = 90
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (fromUser) {
                        val opacity = (progress + 10) / 100f
                        padView.setSelectedOpacity(opacity)
                        opacityLabel.text = "Opacidad: ${progress + 10}%"
                    }
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        opacityRow.addView(opacityBar, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bodyContainer.addView(opacityRow)

        // --- ROW 4: Layout actions (add macro button, delete, restore, save) ---
        val actionRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, Theme.dp(context, Theme.SPACE_XS), 0, 0)
        }

        val addMacroBtn = Button(context).apply {
            text = "+ Botón Macro"
            textSize = 12f
            setTextColor(Theme.ACCENT)
            background = GradientDrawable().apply {
                setColor(Theme.ACCENT_WASH_HIGH)
                cornerRadius = Theme.dp(context, Theme.RADIUS_SM).toFloat()
                setStroke(Theme.dp(context, 1), Theme.ACCENT)
            }
            val hp = Theme.dp(context, Theme.SPACE_MD); val vp = Theme.dp(context, 4)
            setPadding(hp, vp, hp, vp)
            minimumHeight = Theme.dp(context, 36)
            setOnClickListener {
                Haptics.feedback(this, HapticFeedbackConstants.VIRTUAL_KEY)
                showAddMacroButtonPicker()
            }
        }
        actionRow.addView(addMacroBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            marginEnd = Theme.dp(context, Theme.SPACE_SM)
        })

        deleteBtn = Button(context).apply {
            text = "Eliminar control"
            textSize = 12f
            setTextColor(Theme.ERROR)
            background = GradientDrawable().apply {
                setColor(0x26FF7B72)
                cornerRadius = Theme.dp(context, Theme.RADIUS_SM).toFloat()
                setStroke(Theme.dp(context, 1), 0x80FF7B72)
            }
            val hp = Theme.dp(context, Theme.SPACE_MD); val vp = Theme.dp(context, 4)
            setPadding(hp, vp, hp, vp)
            minimumHeight = Theme.dp(context, 36)
            isEnabled = false
            alpha = 0.40f
            setOnClickListener {
                Haptics.feedback(this, HapticFeedbackConstants.LONG_PRESS)
                if (padView.removeSelectedControl()) {
                    updateControlInfo(null)
                }
            }
        }
        actionRow.addView(deleteBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            marginEnd = Theme.dp(context, Theme.SPACE_SM)
        })

        val resetBtn = Button(context).apply {
            text = "Restaurar"
            textSize = 12f
            setTextColor(Theme.WARNING) // Soft coral
            background = GradientDrawable().apply {
                setColor(0x26FFCC66)
                cornerRadius = Theme.dp(context, Theme.RADIUS_SM).toFloat()
            }
            val hp = Theme.dp(context, Theme.SPACE_MD); val vp = Theme.dp(context, 4)
            setPadding(hp, vp, hp, vp)
            minimumHeight = Theme.dp(context, 36)
            setOnClickListener {
                Haptics.feedback(this, HapticFeedbackConstants.VIRTUAL_KEY)
                onResetDefault()
            }
        }
        actionRow.addView(resetBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            marginEnd = Theme.dp(context, Theme.SPACE_SM)
        })

        val saveBtn = Button(context).apply {
            text = "Listo / Guardar"
            textSize = 12f
            setTextColor(Theme.TEXT_PRIMARY)
            background = GradientDrawable().apply {
                setColor(Theme.SURFACE)
                cornerRadius = Theme.dp(context, Theme.RADIUS_SM).toFloat()
                setStroke(Theme.dp(context, 1), Theme.ACCENT)
            }
            val hp = Theme.dp(context, Theme.SPACE_LG); val vp = Theme.dp(context, 4)
            setPadding(hp, vp, hp, vp)
            minimumHeight = Theme.dp(context, 38)
            setOnClickListener {
                padView.setEditMode(false)
                onSaveAndExit()
            }
        }
        actionRow.addView(saveBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val actionScroll = HorizontalScrollView(context).apply {
            isHorizontalScrollBarEnabled = false
        }
        actionScroll.addView(actionRow)
        bodyContainer.addView(actionScroll)

        addView(
            container,
            LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                val m = Theme.dp(context, Theme.SPACE_SM)
                leftMargin = m; rightMargin = m; bottomMargin = m
            }
        )

        // Listen for control selection changes
        padView.onControlSelected = { control ->
            updateControlInfo(control)
            if (control != null) {
                Haptics.feedback(this, HapticFeedbackConstants.VIRTUAL_KEY)
            }
        }

        padView.onLayoutModified = {
            updateControlInfo(padView.selectedControl)
        }
        Theme.applyTypography(this)
    }

    private fun updateControlInfo(control: PadLayout.Control?) {
        if (control != null) {
            val name = formatControlName(control)
            val radPct = (control.r * 100).toInt()
            val opPct = (control.opacity * 100).toInt()
            infoText.text = "$name (R: $radPct%, Op: $opPct%)"
            opacityLabel.text = "Opacidad: $opPct%"
            opacityBar.progress = (opPct - 10).coerceIn(0, 90)
            opacityBar.isEnabled = true
            deleteBtn.isEnabled = true
            deleteBtn.alpha = 1.0f
        } else {
            infoText.text = "Toca un control para editarlo"
            opacityLabel.text = "Opacidad: --"
            opacityBar.isEnabled = false
            deleteBtn.isEnabled = false
            deleteBtn.alpha = 0.40f
        }
    }

    private fun updateSnapGridStyle() {
        val on = padView.snapToGrid
        snapGridBtn.text = if (on) "Cuadrícula: SÍ" else "Cuadrícula: NO"
        snapGridBtn.setTextColor(if (on) Theme.ACCENT else Theme.TEXT_PRIMARY)
        snapGridBtn.background = GradientDrawable().apply {
            setColor(if (on) Theme.ACCENT_WASH_HIGH else Theme.SURFACE)
            cornerRadius = Theme.dp(context, Theme.RADIUS_SM).toFloat()
            if (on) {
                setStroke(Theme.dp(context, 1), Theme.ACCENT)
            } else {
                setStroke(Theme.dp(context, 1), 0x55FFFFFF)
            }
        }
    }

    private fun formatControlName(c: PadLayout.Control): String {
        if (c.id.startsWith("macro_") || !c.macroId.isNullOrEmpty()) {
            val macro = c.macroId?.let { MacroManager.getInstance(context).getMacro(it) }
            val name = macro?.name ?: c.label.ifEmpty { "Macro" }
            return "Botón Macro ⚡: $name"
        }
        return when (c.id) {
            "stick_l" -> "Joystick Izquierdo (L)"
            "stick_r" -> "Joystick Derecho (R)"
            "dpad" -> "Cruceta D-Pad"
            "a" -> "Botón A (Derecha)"
            "b" -> "Botón B (Abajo)"
            "x" -> "Botón X (Arriba)"
            "y" -> "Botón Y (Izquierda)"
            "l" -> "Gatillo L"
            "zl" -> "Gatillo ZL"
            "r" -> "Gatillo R"
            "zr" -> "Gatillo ZR"
            "start" -> "Botón Start"
            "select" -> "Botón Select"
            "home" -> "Botón Home"
            "l3" -> "Botón L3"
            "r3" -> "Botón R3"
            "touchpad" -> "Panel Táctil"
            else -> c.label.ifEmpty { c.id }
        }
    }

    private fun createVerticalDivider(context: Context): View {
        return View(context).apply {
            setBackgroundColor(Theme.OUTLINE)
            layoutParams = LinearLayout.LayoutParams(Theme.dp(context, 1), Theme.dp(context, 24)).apply {
                marginStart = Theme.dp(context, Theme.SPACE_SM)
                marginEnd = Theme.dp(context, Theme.SPACE_SM)
            }
        }
    }

    private var pendingMacroReplacement: Macro? = null
    private var recordingStartedFromEditMode: Boolean = false

    /** Starts the existing immersive capture flow from either the macro library or edit mode. */
    fun startMacroRecording(targetMacro: Macro? = null) {
        pendingMacroReplacement = targetMacro?.deepCopy()
        recordingStartedFromEditMode = padView.editing
        visibility = View.VISIBLE
        startMacroRecordingFlow()
    }

    private fun startMacroRecordingFlow() {
        visibility = View.VISIBLE
        (layoutParams as? FrameLayout.LayoutParams)?.let { params ->
            params.height = ViewGroup.LayoutParams.MATCH_PARENT
            params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            layoutParams = params
        }
        container.visibility = View.GONE
        padView.selectControl(null)
        recordingBannerText.text = "🔴 GRABANDO... Toca aquí para detener"
        recordingBanner.visibility = View.VISIBLE
        padView.startRecordingMacro()

        padView.onMacroEventRecorded = { count ->
            recordingBannerText.text = "🔴 GRABANDO ($count eventos)... Toca aquí para detener"
        }
    }

    private fun stopMacroRecordingFlow() {
        val events = padView.stopRecordingMacro()
        padView.onMacroEventRecorded = null
        recordingBanner.visibility = View.GONE
        (layoutParams as? FrameLayout.LayoutParams)?.let { params ->
            params.height = ViewGroup.LayoutParams.WRAP_CONTENT
            params.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            layoutParams = params
        }
        container.visibility = if (recordingStartedFromEditMode) View.VISIBLE else View.GONE
        if (!recordingStartedFromEditMode) visibility = View.GONE

        if (events.isEmpty()) {
            AlertDialog.Builder(context)
                .setTitle("Grabación finalizada")
                .setMessage("No se registraron pulsaciones de botones.")
                .setPositiveButton("Reintentar") { _, _ ->
                    startMacroRecordingFlow()
                }
                .setNegativeButton("Descartar") { _, _ ->
                    pendingMacroReplacement = null
                }
                .show()
            return
        }

        val replacing = pendingMacroReplacement
        pendingMacroReplacement = null
        if (replacing != null) {
            MacroManager.getInstance(context).saveMacro(
                Macro(replacing.id, replacing.name, events.map { it.copy() }.toMutableList())
            )
            Toast.makeText(context, "Macro '${replacing.name}' actualizada", Toast.LENGTH_SHORT).show()
            padView.invalidate()
            return
        }

        showMacroResultDialog(events)
    }

    private fun showMacroResultDialog(events: List<MacroEvent>) {
        val input = EditText(context).apply {
            hint = "Nombre de la macro"
            val count = MacroManager.getInstance(context).listMacros().size + 1
            setText("Macro $count")
            selectAll()
            setTextColor(Theme.TEXT_PRIMARY)
            setHintTextColor(Theme.TEXT_SECONDARY)
        }

        AlertDialog.Builder(context)
            .setTitle("Grabación Finalizada")
            .setMessage("${events.size} eventos registrados.\n\nIntroduce un nombre para la nueva macro:")
            .setView(FrameLayout(context).apply {
                val p = Theme.dp(context, Theme.SPACE_LG)
                setPadding(p, p, p, p)
                addView(input)
            })
            .setPositiveButton("Guardar") { _, _ ->
                val macroName = input.text.toString().trim().ifEmpty {
                    "Macro ${MacroManager.getInstance(context).listMacros().size + 1}"
                }
                val newId = "macro_${System.currentTimeMillis()}"
                val macro = Macro(newId, macroName, events.toMutableList())
                MacroManager.getInstance(context).saveMacro(macro)
                Toast.makeText(context, "Macro '$macroName' guardada con éxito", Toast.LENGTH_SHORT).show()
                padView.invalidate()
            }
            .setNeutralButton("Reintentar") { _, _ ->
                startMacroRecordingFlow()
            }
            .setNegativeButton("Descartar") { _, _ ->
                Toast.makeText(context, "Macro descartada", Toast.LENGTH_SHORT).show()
            }
            .setCancelable(false)
            .show()
    }

    private fun findFreeMacroButtonPosition(): Pair<Float, Float> {
        val controls = padView.layout.controls
        val width = padView.width.coerceAtLeast(1).toFloat()
        val height = padView.height.coerceAtLeast(1).toFloat()
        val unit = minOf(width, height)
        val offsets = mutableListOf(0f to 0f)
        for (step in 1..8) {
            val d = step * 0.05f
            // Prefer the natural diagonal displacement requested for subsequent macro buttons.
            offsets += listOf(
                d to d, -d to d, d to -d, -d to -d,
                d to 0f, -d to 0f, 0f to d, 0f to -d
            )
        }

        var best: Pair<Float, Float> = 0.50f to 0.50f
        var bestClearance = Float.NEGATIVE_INFINITY
        for ((dx, dy) in offsets) {
            val x = 0.50f + dx
            val y = 0.50f + dy
            if (x !in 0.10f..0.90f || y !in 0.10f..0.90f) continue
            var clearance = Float.POSITIVE_INFINITY
            var free = true
            for (control in controls) {
                val pixelDx = (x - control.cx) * width
                val pixelDy = (y - control.cy) * height
                val distance = kotlin.math.hypot(pixelDx, pixelDy)
                val required = (0.055f + control.r + 0.012f) * unit
                clearance = minOf(clearance, distance - required)
                if (distance < required) free = false
            }
            if (controls.isEmpty()) clearance = Float.POSITIVE_INFINITY
            if (free) return x to y
            if (clearance > bestClearance) {
                bestClearance = clearance
                best = x to y
            }
        }
        return best
    }

    private fun showAddMacroButtonPicker() {
        val macroManager = MacroManager.getInstance(context)
        val macros = macroManager.listMacros()
        if (macros.isEmpty()) {
            AlertDialog.Builder(context)
                .setTitle("Sin macros guardadas")
                .setMessage("Aún no tienes macros guardadas. Abre «⚡ Macros» en la barra principal para grabar una nueva.")
                .setPositiveButton("Entendido", null)
                .show()
            return
        }

        val items = macros.map { "⚡ ${it.name} (${it.events.size} eventos)" }.toTypedArray()
        AlertDialog.Builder(context)
            .setTitle("Vincular Macro al Botón")
            .setItems(items) { _, which ->
                val chosen = macros[which]
                val newId = "macro_${System.currentTimeMillis()}"
                val freePosition = findFreeMacroButtonPosition()
                val newCtrl = PadLayout.Control(
                    id = newId,
                    kind = PadLayout.Kind.BUTTON,
                    bit = 0,
                    label = "⚡",
                    stick = 0,
                    cx = freePosition.first,
                    cy = freePosition.second,
                    r = 0.055f,
                    opacity = 1.0f,
                    macroId = chosen.id
                )
                padView.layout.controls.add(newCtrl)
                padView.selectControl(newCtrl)
                padView.onLayoutModified?.invoke()
                padView.invalidate()
                Toast.makeText(context, "Botón de macro añadido: ${chosen.name}", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
