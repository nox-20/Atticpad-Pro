package net.atticpad

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path

/**
 * Visual styles for action buttons and controller rendering.
 *
 * Requirements:
 * 1. Xbox: A/B/X/Y with characteristic colors:
 *    - Bottom: A (Green)
 *    - Right: B (Red)
 *    - Left: X (Blue)
 *    - Top: Y (Yellow)
 * 2. PlayStation: ✕ ○ □ △ with characteristic colors:
 *    - Bottom: ✕ (Cyan/Blue Cross)
 *    - Right: ○ (Red Circle)
 *    - Left: □ (Pink Square)
 *    - Top: △ (Green Triangle)
 * 3. Clásico Nintendo: app's current classic styling (white A/B/X/Y labels).
 *
 * CRITICAL RULE:
 * Changing the visual style ONLY changes the rendered appearance on the phone screen.
 * The underlying BTN_* bits sent over the wire depend strictly on the physical button
 * position, never the rendered label/symbol.
 */
enum class ButtonStyle(val id: String, val displayName: String) {
    NINTENDO("nintendo", "Clásico Nintendo"),
    XBOX("xbox", "Xbox"),
    PLAYSTATION("playstation", "PlayStation");

    companion object {
        fun fromId(id: String?): ButtonStyle =
            entries.firstOrNull { it.id.equals(id, ignoreCase = true) } ?: NINTENDO
    }
}

typealias PadStyle = ButtonStyle

enum class SymbolType {
    NONE,
    CROSS,
    CIRCLE,
    SQUARE,
    TRIANGLE
}

data class ActionButtonVisual(
    val label: String,
    val symbol: SymbolType,
    val strokeColor: Int,
    val fillColor: Int,
    val textColor: Int
)

object VisualTheme {

    // PlayStation trademark colors
    const val PS_BLUE = 0xFF2979FF.toInt()    // ✕ Cross
    const val PS_RED = 0xFFFF3D00.toInt()     // ○ Circle
    const val PS_PINK = 0xFFFF4081.toInt()    // □ Square
    const val PS_GREEN = 0xFF00E676.toInt()   // △ Triangle

    // Xbox trademark colors
    const val XBOX_GREEN = 0xFF2E7D32.toInt()  // A (Bottom)
    const val XBOX_RED = 0xFFC62828.toInt()    // B (Right)
    const val XBOX_BLUE = 0xFF1565C0.toInt()   // X (Left)
    const val XBOX_YELLOW = 0xFFF9A825.toInt() // Y (Top)

    /**
     * Resolves display label, symbol, and colors for a physical action button.
     * Physical layout positions:
     * - "b": bottom button (Nintendo B position)
     * - "a": right button (Nintendo A position)
     * - "y": left button (Nintendo Y position)
     * - "x": top button (Nintendo X position)
     */
    fun getVisual(controlId: String, style: ButtonStyle, active: Boolean): ActionButtonVisual {
        return when (style) {
            ButtonStyle.XBOX -> when (controlId) {
                // Bottom physical button -> Xbox "A" (Green)
                "b" -> ActionButtonVisual(
                    label = "A",
                    symbol = SymbolType.NONE,
                    strokeColor = XBOX_GREEN,
                    fillColor = if (active) XBOX_GREEN else 0x4D000000 or (XBOX_GREEN and 0x00FFFFFF),
                    textColor = Color.WHITE
                )
                // Right physical button -> Xbox "B" (Red)
                "a" -> ActionButtonVisual(
                    label = "B",
                    symbol = SymbolType.NONE,
                    strokeColor = XBOX_RED,
                    fillColor = if (active) XBOX_RED else 0x4D000000 or (XBOX_RED and 0x00FFFFFF),
                    textColor = Color.WHITE
                )
                // Left physical button -> Xbox "X" (Blue)
                "y" -> ActionButtonVisual(
                    label = "X",
                    symbol = SymbolType.NONE,
                    strokeColor = XBOX_BLUE,
                    fillColor = if (active) XBOX_BLUE else 0x4D000000 or (XBOX_BLUE and 0x00FFFFFF),
                    textColor = Color.WHITE
                )
                // Top physical button -> Xbox "Y" (Yellow)
                "x" -> ActionButtonVisual(
                    label = "Y",
                    symbol = SymbolType.NONE,
                    strokeColor = XBOX_YELLOW,
                    fillColor = if (active) XBOX_YELLOW else 0x4D000000 or (XBOX_YELLOW and 0x00FFFFFF),
                    textColor = Color.BLACK
                )
                else -> defaultVisual(controlId, active)
            }

            ButtonStyle.PLAYSTATION -> when (controlId) {
                // Bottom physical button -> PlayStation Cross (✕)
                "b" -> ActionButtonVisual(
                    label = "",
                    symbol = SymbolType.CROSS,
                    strokeColor = PS_BLUE,
                    fillColor = if (active) (0x66000000.toInt() or (PS_BLUE and 0x00FFFFFF)) else 0xE620242B.toInt(),
                    textColor = Color.WHITE
                )
                // Right physical button -> PlayStation Circle (○)
                "a" -> ActionButtonVisual(
                    label = "",
                    symbol = SymbolType.CIRCLE,
                    strokeColor = PS_RED,
                    fillColor = if (active) (0x66000000.toInt() or (PS_RED and 0x00FFFFFF)) else 0xE620242B.toInt(),
                    textColor = Color.WHITE
                )
                // Left physical button -> PlayStation Square (□)
                "y" -> ActionButtonVisual(
                    label = "",
                    symbol = SymbolType.SQUARE,
                    strokeColor = PS_PINK,
                    fillColor = if (active) (0x66000000.toInt() or (PS_PINK and 0x00FFFFFF)) else 0xE620242B.toInt(),
                    textColor = Color.WHITE
                )
                // Top physical button -> PlayStation Triangle (△)
                "x" -> ActionButtonVisual(
                    label = "",
                    symbol = SymbolType.TRIANGLE,
                    strokeColor = PS_GREEN,
                    fillColor = if (active) (0x66000000.toInt() or (PS_GREEN and 0x00FFFFFF)) else 0xE620242B.toInt(),
                    textColor = Color.WHITE
                )
                else -> defaultVisual(controlId, active)
            }

            ButtonStyle.NINTENDO -> defaultVisual(controlId, active)
        }
    }

    private fun defaultVisual(controlId: String, active: Boolean): ActionButtonVisual {
        val label = when (controlId) {
            "a" -> "A"
            "b" -> "B"
            "x" -> "X"
            "y" -> "Y"
            else -> ""
        }
        return ActionButtonVisual(
            label = label,
            symbol = SymbolType.NONE,
            strokeColor = 0x80FFFFFF.toInt(),
            fillColor = if (active) 0xCCFFFFFF.toInt() else 0x33282D37.toInt(),
            textColor = if (active) Color.BLACK else Color.WHITE
        )
    }

    private val psPath by lazy { Path() }
    private val psPaint by lazy {
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
    }

    /**
     * Adjusts the lightness/brightness of a color by a multiplication factor.
     */
    fun adjustLightness(color: Int, factor: Float): Int {
        val hsv = FloatArray(3)
        Color.colorToHSV(color, hsv)
        if (hsv[2] < 0.08f && factor > 1.0f) {
            hsv[2] = (factor - 1.0f) * 0.45f
        } else {
            hsv[2] = (hsv[2] * factor).coerceIn(0f, 1f)
        }
        val alpha = Color.alpha(color)
        return (alpha shl 24) or (Color.HSVToColor(hsv) and 0x00FFFFFF)
    }

    /**
     * Vector drawing of PlayStation symbols on Canvas.
     * Stroke width is ~6-8% of the button radius (or diameter stroke ~14-16%).
     * Optically centered so each symbol feels balanced and aligned.
     */
    fun drawSymbol(
        canvas: Canvas,
        symbol: SymbolType,
        cx: Float,
        cy: Float,
        radius: Float,
        color: Int,
        strokeWidth: Float,
        alphaMultiplier: Float = 1.0f
    ) {
        psPaint.color = color
        psPaint.alpha = ((Color.alpha(color) / 255f) * alphaMultiplier * 255f).toInt().coerceIn(0, 255)
        psPaint.strokeWidth = strokeWidth
        val s = radius * 0.38f

        when (symbol) {
            SymbolType.CROSS -> {
                // Cross ✕: optically centered with round caps
                canvas.drawLine(cx - s, cy - s, cx + s, cy + s, psPaint)
                canvas.drawLine(cx - s, cy + s, cx + s, cy - s, psPaint)
            }
            SymbolType.CIRCLE -> {
                // Circle ○: balanced radius
                canvas.drawCircle(cx, cy, s, psPaint)
            }
            SymbolType.SQUARE -> {
                // Square □: subtle rounded corners matching PS style
                val rect = android.graphics.RectF(cx - s, cy - s, cx + s, cy + s)
                canvas.drawRoundRect(rect, s * 0.16f, s * 0.16f, psPaint)
            }
            SymbolType.TRIANGLE -> {
                // Triangle △: centroid optically adjusted upward so it doesn't sag
                val topY = cy - s * 1.15f
                val bottomY = cy + s * 0.65f
                val halfW = s * 1.05f
                psPath.reset()
                psPath.moveTo(cx, topY)
                psPath.lineTo(cx + halfW, bottomY)
                psPath.lineTo(cx - halfW, bottomY)
                psPath.close()
                canvas.drawPath(psPath, psPaint)
            }
            SymbolType.NONE -> {}
        }
    }
}
