package net.atticpad

import android.app.AlertDialog
import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/**
 * Settings and Profile management dialog.
 *
 * Provides full UI for:
 * - Entering Edit Mode
 * - Visual Button Style selector: Xbox, PlayStation, Nintendo
 * - Profile Management: Switch profile, Create new, Duplicate, Rename, Delete, Reset
 * - Connection options (Reconnect, Self-test, Disconnect)
 */
object SettingsDialog {

    var activeDialog: AlertDialog? = null

    fun show(
        context: Context,
        profileManager: ProfileManager,
        currentStyle: ButtonStyle? = null,
        currentOrientation: PadLayout.Orientation,
        onStyleChanged: (ButtonStyle) -> Unit,
        onProfileChanged: (PadProfile) -> Unit,
        onEnterEditMode: () -> Unit,
        onResetDefault: () -> Unit,
        onReconnect: () -> Unit,
        onDisconnect: () -> Unit,
        onSelfTest: () -> Unit
    ) {
        var dialog: AlertDialog? = null

        val scroll = ScrollView(context)
        val content = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            val p = Theme.dp(context, Theme.SPACE_LG)
            setPadding(p, p, p, p)
            setBackgroundColor(Theme.BG)
        }

        // --- Title ---
        val titleText = TextView(context).apply {
            text = "Ajustes y Personalización"
            textSize = 20f
            setTextColor(Theme.TEXT_PRIMARY)
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, 0, 0, Theme.dp(context, Theme.SPACE_MD))
        }
        content.addView(titleText)

        // --- SECTION 1: MODO EDICIÓN ---
        content.addView(createSectionHeader(context, "DISTRIBUCIÓN DEL MANDO"))

        val editModeBtn = Button(context).apply {
            text = "✏ Entrar en Modo Edición"
            textSize = 14f
            setTextColor(Theme.ACCENT_ON)
            background = GradientDrawable().apply {
                setColor(Theme.ACCENT)
                cornerRadius = Theme.dp(context, Theme.RADIUS_SM).toFloat()
            }
            val p = Theme.dp(context, Theme.SPACE_MD)
            setPadding(p, p, p, p)
            setOnClickListener {
                dialog?.dismiss()
                onEnterEditMode()
            }
        }
        content.addView(editModeBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = Theme.dp(context, Theme.SPACE_MD)
        })

        // --- SECTION 2: ESTILO VISUAL ---
        content.addView(createSectionHeader(context, "ESTILO VISUAL DE BOTONES"))

        val activeProfile = profileManager.getActiveProfile()
        val activeStyle = currentStyle ?: activeProfile.style
        val styleRadioGroup = RadioGroup(context).apply {
            orientation = RadioGroup.VERTICAL
        }

        val styles = listOf(
            ButtonStyle.XBOX to "Xbox",
            ButtonStyle.PLAYSTATION to "PlayStation",
            ButtonStyle.NINTENDO to "Nintendo"
        )

        val buttonMap = mutableMapOf<Int, ButtonStyle>()
        var activeCheckedId = -1

        for ((style, desc) in styles) {
            val viewId = View.generateViewId()
            val isCurrent = (style == activeStyle)
            val rb = RadioButton(context).apply {
                id = viewId
                text = desc
                textSize = 13f
                setTextColor(Theme.TEXT_PRIMARY)
                setPadding(Theme.dp(context, Theme.SPACE_XS), Theme.dp(context, Theme.SPACE_XS), 0, Theme.dp(context, Theme.SPACE_XS))
            }
            buttonMap[viewId] = style
            styleRadioGroup.addView(rb)
            if (isCurrent) {
                activeCheckedId = viewId
            }
        }

        if (activeCheckedId != -1) {
            styleRadioGroup.check(activeCheckedId)
        }

        styleRadioGroup.setOnCheckedChangeListener { _, checkedId ->
            val selectedStyle = buttonMap[checkedId] ?: return@setOnCheckedChangeListener
            activeProfile.style = selectedStyle
            profileManager.saveActiveProfile()
            onStyleChanged(selectedStyle)
        }

        content.addView(styleRadioGroup, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = Theme.dp(context, Theme.SPACE_MD)
        })

        // --- SECTION 3: PERFILES ---
        content.addView(createSectionHeader(context, "PERFILES DE MANDO"))

        val activeProfileCard = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val p = Theme.dp(context, Theme.SPACE_SM)
            setPadding(p, p, p, p)
            background = GradientDrawable().apply {
                setColor(Theme.ACCENT_WASH_HIGH)
                cornerRadius = Theme.dp(context, Theme.RADIUS_SM).toFloat()
                setStroke(Theme.dp(context, 1), Theme.ACCENT)
            }
        }

        val profileDesc = TextView(context).apply {
            text = "Perfil activo: ${activeProfile.name}"
            textSize = 13f
            setTextColor(Theme.ACCENT)
        }
        activeProfileCard.addView(profileDesc, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        var refreshProfiles: (() -> Unit)? = null

        val quickSwitchBtn = Button(context).apply {
            text = "Cambiar ▾"
            textSize = 11f
            setTextColor(Theme.ACCENT_ON)
            background = GradientDrawable().apply {
                setColor(Theme.ACCENT)
                cornerRadius = Theme.dp(context, 4).toFloat()
            }
            val hp = Theme.dp(context, Theme.SPACE_SM); val vp = Theme.dp(context, 2)
            setPadding(hp, vp, hp, vp)
            minimumHeight = Theme.dp(context, 28)
            setOnClickListener {
                showQuickProfilePicker(context, profileManager) { switched ->
                    onProfileChanged(switched)
                    dialog?.dismiss()
                }
            }
        }
        activeProfileCard.addView(quickSwitchBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        content.addView(activeProfileCard, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = Theme.dp(context, Theme.SPACE_XS)
        })

        // Quick profile chips row
        val quickChipsScroll = HorizontalScrollView(context).apply {
            isHorizontalScrollBarEnabled = false
        }
        val quickChipsRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, Theme.dp(context, Theme.SPACE_XS), 0, Theme.dp(context, Theme.SPACE_SM))
        }
        quickChipsScroll.addView(quickChipsRow)
        content.addView(quickChipsScroll)

        // Profiles list container
        val profilesListContainer = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
        }

        fun refreshProfileList() {
            refreshProfiles = { refreshProfileList() }
            profilesListContainer.removeAllViews()
            quickChipsRow.removeAllViews()
            val current = profileManager.getActiveProfile()
            profileDesc.text = "Perfil activo: ${current.name}"
            val matchingViewId = buttonMap.entries.firstOrNull { it.value == current.style }?.key
            if (matchingViewId != null) {
                styleRadioGroup.check(matchingViewId)
            }

            // Populate quick chips
            for (p in profileManager.listProfiles()) {
                val isCurrent = (p.id == current.id)
                val chip = TextView(context).apply {
                    text = if (isCurrent) "✓ ${p.name}" else p.name
                    textSize = 11f
                    setTextColor(if (isCurrent) Theme.ACCENT_ON else Theme.TEXT_PRIMARY)
                    background = GradientDrawable().apply {
                        setColor(if (isCurrent) Theme.ACCENT else Theme.OUTLINE)
                        cornerRadius = Theme.dp(context, 12).toFloat()
                        if (isCurrent) setStroke(Theme.dp(context, 1), Theme.ACCENT)
                    }
                    val hp = Theme.dp(context, 10); val vp = Theme.dp(context, 4)
                    setPadding(hp, vp, hp, vp)
                    isClickable = true
                    setOnClickListener {
                        if (!isCurrent) {
                            val switched = profileManager.setActiveProfile(p.id)
                            onProfileChanged(switched)
                            refreshProfileList()
                        }
                    }
                }
                quickChipsRow.addView(
                    chip,
                    LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                        marginEnd = Theme.dp(context, Theme.SPACE_XS)
                    }
                )
            }

            // Populate detailed profile rows
            for (p in profileManager.listProfiles()) {
                val isCurrent = (p.id == current.id)
                val row = LinearLayout(context).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    val hp = Theme.dp(context, Theme.SPACE_SM); val vp = Theme.dp(context, 3)
                    setPadding(hp, vp, hp, vp)
                    background = GradientDrawable().apply {
                        setColor(if (isCurrent) Theme.ACCENT_WASH_HIGH else Theme.OUTLINE_SUBTLE)
                        cornerRadius = Theme.dp(context, Theme.RADIUS_SM).toFloat()
                        if (isCurrent) setStroke(Theme.dp(context, 1), Theme.ACCENT)
                    }
                }

                val infoCol = LinearLayout(context).apply {
                    orientation = LinearLayout.VERTICAL
                }

                val pName = TextView(context).apply {
                    text = p.name
                    textSize = 12f
                    setTextColor(if (isCurrent) Theme.ACCENT else Theme.TEXT_PRIMARY)
                }
                infoCol.addView(pName)

                val pStyleSub = TextView(context).apply {
                    text = "Estilo: ${p.style.name.lowercase().replaceFirstChar { it.uppercase() }}"
                    textSize = 9f
                    setTextColor(Theme.TEXT_SECONDARY)
                }
                infoCol.addView(pStyleSub)

                row.addView(infoCol, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

                // If NOT current: Show prominent "Activar" button
                if (!isCurrent) {
                    val activateBtn = Button(context).apply {
                        text = "Activar"
                        textSize = 10f
                        setTextColor(Theme.ACCENT_ON)
                        background = GradientDrawable().apply {
                            setColor(Theme.ACCENT)
                            cornerRadius = Theme.dp(context, Theme.RADIUS_SM).toFloat()
                        }
                        val hp = Theme.dp(context, 6); val vp = Theme.dp(context, 1)
                        setPadding(hp, vp, hp, vp)
                        minimumHeight = Theme.dp(context, 26)
                        setOnClickListener {
                            val switched = profileManager.setActiveProfile(p.id)
                            onProfileChanged(switched)
                            refreshProfileList()
                        }
                    }
                    row.addView(activateBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                        marginStart = Theme.dp(context, 4)
                    })
                } else {
                    val activeBadge = TextView(context).apply {
                        text = "Activo ✓"
                        textSize = 10f
                        setTextColor(Theme.ACCENT)
                        background = GradientDrawable().apply {
                            setColor(Theme.ACCENT_WASH_HIGH)
                            cornerRadius = Theme.dp(context, 3).toFloat()
                            setStroke(Theme.dp(context, 1), Theme.ACCENT)
                        }
                        val hp = Theme.dp(context, 6); val vp = Theme.dp(context, 2)
                        setPadding(hp, vp, hp, vp)
                    }
                    row.addView(activeBadge, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                        marginStart = Theme.dp(context, 4)
                    })
                }

                // Duplicate button
                val dupBtn = createSmallButton(context, "Copiar") {
                    val dup = profileManager.duplicateProfile(p.id)
                    onProfileChanged(dup)
                    refreshProfileList()
                }
                row.addView(dupBtn)

                // Rename button
                val renBtn = createSmallButton(context, "Renombrar") {
                    showRenameDialog(context, p) { newName ->
                        profileManager.renameProfile(p.id, newName)
                        refreshProfileList()
                    }
                }
                row.addView(renBtn)

                // Delete button (if more than 1)
                if (profileManager.listProfiles().size > 1) {
                    val delBtn = createSmallButton(context, "✕") {
                        showDeleteConfirmDialog(context, p) {
                            if (profileManager.deleteProfile(p.id)) {
                                onProfileChanged(profileManager.getActiveProfile())
                                refreshProfileList()
                            }
                        }
                    }
                    row.addView(delBtn)
                }

                profilesListContainer.addView(
                    row,
                    LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                        bottomMargin = Theme.dp(context, 3)
                    }
                )
            }
        }

        refreshProfileList()
        content.addView(profilesListContainer)

        // New profile button
        val newProfileBtn = Button(context).apply {
            text = "+ Crear Nuevo Perfil"
            textSize = 12f
            setTextColor(Theme.TEXT_PRIMARY)
            background = Theme.secondaryButtonBackground(context)
            val p = Theme.dp(context, Theme.SPACE_SM)
            setPadding(p, p, p, p)
            setOnClickListener {
                showCreateProfileDialog(context) { name ->
                    val created = profileManager.createProfile(name)
                    onProfileChanged(created)
                    refreshProfileList()
                }
            }
        }
        content.addView(newProfileBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = Theme.dp(context, Theme.SPACE_XS)
            bottomMargin = Theme.dp(context, Theme.SPACE_MD)
        })

        // --- SECTION 4: AJUSTES GENERALES ---
        content.addView(createSectionHeader(context, "AJUSTES GENERALES"))

        val hapticsRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val p = Theme.dp(context, Theme.SPACE_SM)
            setPadding(p, p, p, p)
            background = GradientDrawable().apply {
                setColor(Theme.OUTLINE_SUBTLE)
                cornerRadius = Theme.dp(context, Theme.RADIUS_SM).toFloat()
            }
        }

        val hapticsLabel = TextView(context).apply {
            text = "Respuesta háptica al pulsar"
            textSize = 13f
            setTextColor(Theme.TEXT_PRIMARY)
        }
        hapticsRow.addView(hapticsLabel, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        val hapticsSwitch = Switch(context).apply {
            isChecked = Haptics.isEnabled(context)
            setOnCheckedChangeListener { _, isChecked ->
                Haptics.setEnabled(context, isChecked)
                if (isChecked) {
                    Haptics.feedback(this, HapticFeedbackConstants.VIRTUAL_KEY)
                }
            }
        }
        hapticsRow.addView(hapticsSwitch, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        content.addView(hapticsRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = Theme.dp(context, Theme.SPACE_LG)
        })

        // --- SECTION 5: SESIÓN Y CONEXIÓN ---
        content.addView(createSectionHeader(context, "CONEXIÓN Y DIAGNÓSTICO"))

        val connRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
        }

        val reconnBtn = Button(context).apply {
            text = "Reconectar"
            textSize = 12f
            setTextColor(Theme.TEXT_PRIMARY)
            background = Theme.secondaryButtonBackground(context)
            setOnClickListener {
                dialog?.dismiss()
                onReconnect()
            }
        }
        connRow.addView(reconnBtn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginEnd = Theme.dp(context, Theme.SPACE_XS)
        })

        val selfTestBtn = Button(context).apply {
            text = "Autodiagnóstico"
            textSize = 12f
            setTextColor(Theme.TEXT_PRIMARY)
            background = Theme.secondaryButtonBackground(context)
            setOnClickListener {
                dialog?.dismiss()
                onSelfTest()
            }
        }
        connRow.addView(selfTestBtn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginStart = Theme.dp(context, Theme.SPACE_XS)
        })

        content.addView(connRow, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = Theme.dp(context, Theme.SPACE_SM)
        })

        val disconnectBtn = Button(context).apply {
            text = "Detener conexión"
            textSize = 12f
            setTextColor(Theme.ERROR)
            background = GradientDrawable().apply {
                setColor(0x26FF7B72)
                cornerRadius = Theme.dp(context, Theme.RADIUS_SM).toFloat()
                setStroke(Theme.dp(context, 1), 0x80FF7B72)
            }
            setOnClickListener {
                dialog?.dismiss()
                onDisconnect()
            }
        }
        content.addView(disconnectBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = Theme.dp(context, Theme.SPACE_LG)
        })

        scroll.addView(content)
        Theme.applyTypography(content)

        val builtDialog = AlertDialog.Builder(context)
            .setView(scroll)
            .setPositiveButton("Cerrar", null)
            .create()

        dialog = builtDialog
        activeDialog = builtDialog
        builtDialog.setOnDismissListener {
            if (activeDialog == builtDialog) {
                activeDialog = null
            }
        }

        builtDialog.show()
    }

    private fun createSectionHeader(context: Context, title: String): TextView {
        return TextView(context).apply {
            text = title
            textSize = 11f
            setTextColor(Theme.TEXT_SECONDARY)
            setPadding(0, Theme.dp(context, Theme.SPACE_SM), 0, Theme.dp(context, Theme.SPACE_XS))
        }
    }

    private fun createSmallButton(context: Context, label: String, onClick: () -> Unit): Button {
        return Button(context).apply {
            text = label
            textSize = 10f
            setTextColor(Theme.TEXT_PRIMARY)
            background = Theme.secondaryButtonBackground(context)
            val hp = Theme.dp(context, 6); val vp = Theme.dp(context, 1)
            setPadding(hp, vp, hp, vp)
            minimumHeight = Theme.dp(context, 26)
            minimumWidth = Theme.dp(context, 26)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                marginStart = Theme.dp(context, 4)
            }
            setOnClickListener { onClick() }
        }
    }

    private fun showRenameDialog(context: Context, profile: PadProfile, onRenamed: (String) -> Unit) {
        val input = EditText(context).apply {
            setText(profile.name)
            setSelection(profile.name.length)
            setTextColor(Theme.TEXT_PRIMARY)
            setPadding(Theme.dp(context, 16), Theme.dp(context, 16), Theme.dp(context, 16), Theme.dp(context, 16))
        }

        val d = AlertDialog.Builder(context)
            .setTitle("Renombrar Perfil")
            .setView(input)
            .setPositiveButton("Aceptar") { _, _ ->
                val text = input.text.toString().trim()
                if (text.isNotEmpty()) onRenamed(text)
            }
            .setNegativeButton("Cancelar", null)
            .create()
        activeDialog = d
        d.setOnDismissListener { if (activeDialog == d) activeDialog = null }
        d.show()
    }

    private fun showCreateProfileDialog(context: Context, onCreated: (String) -> Unit) {
        val input = EditText(context).apply {
            hint = "Nombre del perfil (ej. Carreras, Shooter)"
            setHintTextColor(Theme.TEXT_SECONDARY)
            setTextColor(Theme.TEXT_PRIMARY)
            setPadding(Theme.dp(context, 16), Theme.dp(context, 16), Theme.dp(context, 16), Theme.dp(context, 16))
        }

        val d = AlertDialog.Builder(context)
            .setTitle("Nuevo Perfil")
            .setView(input)
            .setPositiveButton("Crear") { _, _ ->
                val text = input.text.toString().trim()
                if (text.isNotEmpty()) onCreated(text)
            }
            .setNegativeButton("Cancelar", null)
            .create()
        activeDialog = d
        d.setOnDismissListener { if (activeDialog == d) activeDialog = null }
        d.show()
    }

    private fun showDeleteConfirmDialog(context: Context, profile: PadProfile, onConfirmed: () -> Unit) {
        val d = AlertDialog.Builder(context)
            .setTitle("Eliminar Perfil")
            .setMessage("¿Estás seguro de que deseas eliminar el perfil '${profile.name}'?")
            .setPositiveButton("Eliminar") { _, _ ->
                onConfirmed()
            }
            .setNegativeButton("Cancelar", null)
            .create()
        activeDialog = d
        d.setOnDismissListener { if (activeDialog == d) activeDialog = null }
        d.show()
    }

    fun showQuickProfilePicker(
        context: Context,
        profileManager: ProfileManager,
        onProfileSelected: (PadProfile) -> Unit
    ) {
        val current = profileManager.getActiveProfile()
        val profiles = profileManager.listProfiles()
        val names = profiles.map { p ->
            val mark = if (p.id == current.id) " (Activo ✓)" else ""
            "${p.name}$mark"
        }.toTypedArray()

        val d = AlertDialog.Builder(context)
            .setTitle("Seleccionar Perfil")
            .setItems(names) { _, which ->
                val chosen = profiles[which]
                val switched = profileManager.setActiveProfile(chosen.id)
                onProfileSelected(switched)
            }
            .setNegativeButton("Cancelar", null)
            .create()
        activeDialog = d
        d.setOnDismissListener { if (activeDialog == d) activeDialog = null }
        d.show()
    }

    /** Dedicated macro library. Recording is deliberately separate from layout editing. */
    fun showMacroLibrary(
        context: Context,
        onRecordNew: () -> Unit,
        onRerecord: (Macro) -> Unit
    ) {
        var dialog: AlertDialog? = null
        val scroll = ScrollView(context)
        val content = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            val p = Theme.dp(context, Theme.SPACE_LG)
            setPadding(p, p, p, p)
            setBackgroundColor(Theme.BG)
        }

        val heading = TextView(context).apply {
            text = "Biblioteca de macros"
            textSize = Theme.TEXT_TITLE
            setTextColor(Theme.TEXT_PRIMARY)
            typeface = Theme.TYPE_BOLD
            setPadding(0, 0, 0, Theme.dp(context, Theme.SPACE_XS))
        }
        content.addView(heading)

        val description = TextView(context).apply {
            text = "Graba secuencias de botones y vuelve a grabarlas cuando quieras."
            textSize = Theme.TEXT_LABEL
            setTextColor(Theme.TEXT_SECONDARY)
            setPadding(0, 0, 0, Theme.dp(context, Theme.SPACE_MD))
        }
        content.addView(description)

        val newMacroButton = Button(context).apply {
            text = "＋ Grabar nueva macro"
            textSize = Theme.TEXT_BODY
            setTextColor(Theme.ACCENT_ON)
            typeface = Theme.TYPE_BOLD
            isAllCaps = false
            background = Theme.primaryButtonBackground(context)
            minimumHeight = Theme.dp(context, Theme.TOUCH_MIN)
            setPadding(Theme.dp(context, Theme.SPACE_MD), 0, Theme.dp(context, Theme.SPACE_MD), 0)
            setOnClickListener {
                dialog?.dismiss()
                onRecordNew()
            }
        }
        content.addView(newMacroButton, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = Theme.dp(context, Theme.SPACE_MD) })

        val list = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL }
        content.addView(list)

        fun refreshList() {
            list.removeAllViews()
            val macros = MacroManager.getInstance(context).listMacros()
            if (macros.isEmpty()) {
                val empty = TextView(context).apply {
                    text = "Todavía no hay macros guardadas.\nUsa «Grabar nueva macro» para crear la primera."
                    textSize = Theme.TEXT_BODY
                    setTextColor(Theme.TEXT_SECONDARY)
                    setPadding(Theme.dp(context, Theme.SPACE_SM), Theme.dp(context, Theme.SPACE_SM),
                        Theme.dp(context, Theme.SPACE_SM), Theme.dp(context, Theme.SPACE_LG))
                }
                list.addView(empty)
                return
            }

            for (macro in macros) {
                val card = LinearLayout(context).apply {
                    orientation = LinearLayout.VERTICAL
                    val p = Theme.dp(context, Theme.SPACE_SM)
                    setPadding(p, p, p, p)
                    background = Theme.cardBackground(context)
                }
                val name = TextView(context).apply {
                    text = "⚡ ${macro.name}"
                    textSize = Theme.TEXT_BODY
                    setTextColor(Theme.ACCENT)
                    typeface = Theme.TYPE_BOLD
                }
                card.addView(name)

                val duration = macro.events.sumOf { it.delayMs }
                val details = TextView(context).apply {
                    text = "${macro.events.size} eventos · ${duration} ms"
                    textSize = Theme.TEXT_CAPTION
                    setTextColor(Theme.TEXT_SECONDARY)
                    setPadding(0, Theme.dp(context, 2), 0, Theme.dp(context, Theme.SPACE_SM))
                }
                card.addView(details)

                val actions = LinearLayout(context).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.END or Gravity.CENTER_VERTICAL
                }
                val rerecord = Button(context).apply {
                    text = "Volver a Grabar"
                    textSize = 10f
                    setTextColor(Theme.ACCENT_ON)
                    typeface = Theme.TYPE_BOLD
                    isAllCaps = false
                    background = Theme.primaryButtonBackground(context)
                    minimumHeight = Theme.dp(context, 36)
                    setPadding(Theme.dp(context, 8), 0, Theme.dp(context, 8), 0)
                    setOnClickListener {
                        dialog?.dismiss()
                        onRerecord(macro.deepCopy())
                    }
                }
                actions.addView(rerecord, LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { marginEnd = Theme.dp(context, 4) })

                val rename = createSmallButton(context, "Renombrar") {
                    showRenameMacroDialog(context, macro) { refreshList() }
                }
                actions.addView(rename)
                val delete = createSmallButton(context, "✕") {
                    showDeleteMacroConfirmDialog(context, macro) {
                        MacroManager.getInstance(context).deleteMacro(macro.id)
                        refreshList()
                    }
                }
                actions.addView(delete)
                card.addView(actions)

                list.addView(card, LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = Theme.dp(context, Theme.SPACE_SM) })
            }
        }
        refreshList()
        scroll.addView(content)
        Theme.applyTypography(content)

        val builtDialog = AlertDialog.Builder(context)
            .setView(scroll)
            .setNegativeButton("Cerrar", null)
            .create()
        dialog = builtDialog
        activeDialog = builtDialog
        builtDialog.setOnDismissListener { if (activeDialog == builtDialog) activeDialog = null }
        builtDialog.show()
    }

    fun showRenameMacroDialog(
        context: Context,
        macro: Macro,
        onUpdated: () -> Unit
    ) {
        val input = EditText(context).apply {
            setText(macro.name)
            selectAll()
            setTextColor(Theme.TEXT_PRIMARY)
            setHintTextColor(Theme.TEXT_SECONDARY)
        }
        val d = AlertDialog.Builder(context)
            .setTitle("Renombrar Macro")
            .setView(FrameLayout(context).apply {
                val p = Theme.dp(context, Theme.SPACE_LG)
                setPadding(p, p, p, p)
                addView(input)
            })
            .setPositiveButton("Guardar") { _, _ ->
                val newName = input.text.toString().trim()
                if (newName.isNotEmpty()) {
                    MacroManager.getInstance(context).renameMacro(macro.id, newName)
                    Toast.makeText(context, "Macro renombrada a '$newName'", Toast.LENGTH_SHORT).show()
                    onUpdated()
                }
            }
            .setNegativeButton("Cancelar", null)
            .create()
        activeDialog = d
        d.setOnDismissListener { if (activeDialog == d) activeDialog = null }
        d.show()
    }

    fun showDeleteMacroConfirmDialog(
        context: Context,
        macro: Macro,
        onConfirmed: () -> Unit
    ) {
        val d = AlertDialog.Builder(context)
            .setTitle("Eliminar Macro")
            .setMessage("¿Estás seguro de que deseas eliminar la macro '${macro.name}'? Los botones asociados a ella dejarán de dispararla.")
            .setPositiveButton("Eliminar") { _, _ ->
                onConfirmed()
                Toast.makeText(context, "Macro eliminada", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancelar", null)
            .create()
        activeDialog = d
        d.setOnDismissListener { if (activeDialog == d) activeDialog = null }
        d.show()
    }

    private fun formatButtonId(id: String): String = when (id.lowercase()) {
        "a" -> "Botón A"
        "b" -> "Botón B"
        "x" -> "Botón X"
        "y" -> "Botón Y"
        "l", "lb" -> "Botón LB / L"
        "r", "rb" -> "Botón RB / R"
        "zl", "lt" -> "Gatillo Izq (LT / ZL)"
        "zr", "rt" -> "Gatillo Der (RT / ZR)"
        "start", "menu" -> "Menu (Start)"
        "select", "view", "back" -> "View (Select / Back)"
        "home", "xbox", "guide" -> "Xbox (Home)"
        "l3" -> "L3 (Stick Izq)"
        "r3" -> "R3 (Stick Der)"
        "dpad_up" -> "D-Pad Arriba"
        "dpad_down" -> "D-Pad Abajo"
        "dpad_left" -> "D-Pad Izquierda"
        "dpad_right" -> "D-Pad Derecha"
        else -> id.uppercase()
    }
}
